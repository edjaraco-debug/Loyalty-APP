import crypto from 'node:crypto';
import { config } from '../config.js';

// Token de sesion firmado tipo JWT (HS256), sin dependencias externas.
// Estructura: <header>.<payload>.<signature> en base64url.

function b64url(input) {
  return Buffer.from(input).toString('base64url');
}

function sign(data) {
  return crypto
    .createHmac('sha256', config.security.sessionSecret)
    .update(data)
    .digest('base64url');
}

/**
 * Firma un token con la informacion de la sesion.
 * @param {object} payload datos a incluir (ej. { sub, role, biz })
 * @param {number} expiresInSec validez en segundos (por defecto 12 horas)
 */
export function signToken(payload, expiresInSec = 60 * 60 * 12) {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64url(JSON.stringify({ ...payload, iat: now, exp: now + expiresInSec }));
  const signature = sign(`${header}.${body}`);
  return `${header}.${body}.${signature}`;
}

/**
 * Verifica la firma y expiracion de un token. Devuelve el payload o null.
 */
export function verifyToken(token) {
  if (typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, body, signature] = parts;

  const expected = sign(`${header}.${body}`);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  let payload;
  try {
    payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (typeof payload.exp !== 'number' || payload.exp < Math.floor(Date.now() / 1000)) {
    return null;
  }
  return payload;
}
