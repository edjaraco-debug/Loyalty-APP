import { verifyToken } from './tokens.js';
import { getUserById } from '../db/users.js';

/**
 * Lee el token "Authorization: Bearer <token>" si existe y, si es valido,
 * carga el usuario en req.user. Nunca bloquea: solo adjunta el usuario.
 */
export async function authenticate(req, _res, next) {
  try {
    const header = req.get('authorization') ?? '';
    const match = header.match(/^Bearer\s+(.+)$/i);
    if (match) {
      const payload = verifyToken(match[1]);
      if (payload?.sub) {
        const user = await getUserById(payload.sub);
        if (user && user.active) req.user = user;
      }
    }
    next();
  } catch (err) {
    next(err);
  }
}

/** Exige una sesion valida (usar despues de authenticate). */
export function requireAuth(req, res, next) {
  if (!req.user) return res.sendStatus(401);
  next();
}

/** Exige que el usuario tenga uno de los roles indicados. */
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.sendStatus(401);
    if (!roles.includes(req.user.role)) return res.sendStatus(403);
    next();
  };
}
