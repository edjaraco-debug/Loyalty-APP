import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { config } from '../config.js';

/**
 * Cabeceras de seguridad HTTP (CSP, HSTS, no-sniff, etc.).
 * Como es una API JSON, desactivamos la CSP por defecto que podria estorbar.
 */
export const securityHeaders = helmet({
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: 'same-site' },
  hsts: config.isProd
    ? { maxAge: 31536000, includeSubDomains: true, preload: true }
    : false,
});

/**
 * Limita peticiones por IP para los endpoints del protocolo Apple Wallet.
 */
export const walletLimiter = rateLimit({
  windowMs: config.security.rateLimit.windowMs,
  max: config.security.rateLimit.walletMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Demasiadas peticiones. Intenta mas tarde.' },
});

/**
 * Limite mas estricto para los endpoints de administracion (protegen PII).
 */
export const adminLimiter = rateLimit({
  windowMs: config.security.rateLimit.windowMs,
  max: config.security.rateLimit.adminMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Demasiadas peticiones de administracion. Intenta mas tarde.' },
});

/**
 * En produccion exige HTTPS. Si llega por HTTP (detras de proxy via
 * x-forwarded-proto), rechaza la peticion.
 */
export function enforceHttps(req, res, next) {
  if (!config.isProd) return next();
  const proto = req.get('x-forwarded-proto') ?? req.protocol;
  if (proto !== 'https') {
    return res.status(403).json({ error: 'Se requiere HTTPS.' });
  }
  next();
}
