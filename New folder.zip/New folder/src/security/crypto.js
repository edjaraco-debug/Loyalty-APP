import crypto from 'node:crypto';
import { config } from '../config.js';

const ALGO = 'aes-256-gcm';
const PREFIX = 'enc:v1:';

let cachedKey;

/**
 * Obtiene la clave de cifrado de 32 bytes desde la configuracion.
 * Acepta una cadena hex de 64 caracteres.
 */
function getKey() {
  if (cachedKey) return cachedKey;
  const hex = config.security.encryptionKey;
  if (!hex || !/^[0-9a-fA-F]{64}$/.test(hex)) {
    throw new Error(
      'ENCRYPTION_KEY invalida. Debe ser una cadena hexadecimal de 64 caracteres (32 bytes). ' +
        'Genera una con: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"',
    );
  }
  cachedKey = Buffer.from(hex, 'hex');
  return cachedKey;
}

/**
 * Cifra un valor de texto (PII como nombre o email) con AES-256-GCM.
 * Devuelve una cadena "enc:v1:<base64>". Si el valor es vacio/null lo devuelve tal cual.
 */
export function encrypt(plain) {
  if (plain === null || plain === undefined || plain === '') return plain;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv);
  const enc = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([iv, tag, enc]).toString('base64');
}

/**
 * Descifra un valor previamente cifrado. Si no tiene el prefijo, lo devuelve sin cambios
 * (compatibilidad con datos antiguos en texto plano).
 */
export function decrypt(value) {
  if (typeof value !== 'string' || !value.startsWith(PREFIX)) return value;
  const data = Buffer.from(value.slice(PREFIX.length), 'base64');
  const iv = data.subarray(0, 12);
  const tag = data.subarray(12, 28);
  const enc = data.subarray(28);
  const decipher = crypto.createDecipheriv(ALGO, getKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
}

/**
 * Comparacion de cadenas resistente a ataques de temporizacion (timing attacks).
 * Hashea ambos valores antes de comparar para evitar filtrar la longitud.
 */
export function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ha = crypto.createHash('sha256').update(a).digest();
  const hb = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/**
 * Genera un token aleatorio seguro (hex).
 */
export function randomToken(bytes = 24) {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Hash SHA-256 en hex. Util para indexar/buscar API keys sin guardarlas en claro.
 * (Las API keys son aleatorias de alta entropia, por lo que el hash directo es seguro.)
 */
export function sha256Hex(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}
