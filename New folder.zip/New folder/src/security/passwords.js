import crypto from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(crypto.scrypt);
const KEYLEN = 64;
const SALT_BYTES = 16;
const PREFIX = 'scrypt';

/**
 * Genera el hash de una contrasena usando scrypt (algoritmo lento por diseno,
 * resistente a ataques de fuerza bruta). No requiere dependencias nativas.
 * Formato almacenado: "scrypt$<saltHex>$<hashHex>".
 */
export async function hashPassword(plain) {
  if (typeof plain !== 'string' || plain.length < 8) {
    throw new Error('La contrasena debe tener al menos 8 caracteres.');
  }
  if (plain.length > 200) {
    throw new Error('La contrasena es demasiado larga.');
  }
  const salt = crypto.randomBytes(SALT_BYTES);
  const derived = await scrypt(plain, salt, KEYLEN);
  return `${PREFIX}$${salt.toString('hex')}$${derived.toString('hex')}`;
}

/**
 * Verifica una contrasena contra un hash almacenado, en tiempo constante.
 * Devuelve false ante cualquier formato invalido (sin lanzar excepciones).
 */
export async function verifyPassword(plain, stored) {
  if (typeof plain !== 'string' || typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 3 || parts[0] !== PREFIX) return false;
  let salt;
  let expected;
  try {
    salt = Buffer.from(parts[1], 'hex');
    expected = Buffer.from(parts[2], 'hex');
  } catch {
    return false;
  }
  if (salt.length === 0 || expected.length === 0) return false;
  const derived = await scrypt(plain, salt, expected.length);
  return crypto.timingSafeEqual(derived, expected);
}

// Hash ficticio para igualar tiempos cuando el usuario no existe (anti-enumeracion).
export const DUMMY_HASH = `${PREFIX}$${'0'.repeat(SALT_BYTES * 2)}$${'0'.repeat(KEYLEN * 2)}`;
