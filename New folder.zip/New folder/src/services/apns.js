import http2 from 'node:http2';
import fs from 'node:fs';
import { config } from '../config.js';
import { getPushTokensForSerial } from '../db/database.js';

const APNS_HOST = 'https://api.push.apple.com';

/**
 * Envia una notificacion push vacia a Apple Wallet para que el dispositivo
 * pida la version actualizada del pass. El payload para passes es {} (vacio).
 *
 * Usa autenticacion por certificado (el mismo del Pass Type ID).
 */
export async function pushUpdateForSerial(serialNumber) {
  const tokens = await getPushTokensForSerial(serialNumber);
  if (tokens.length === 0) {
    return { sent: 0, tokens: [] };
  }

  let cert;
  let key;
  try {
    cert = fs.readFileSync(config.apns.certPath);
    key = fs.readFileSync(config.apns.keyPath);
  } catch (err) {
    console.warn('[apns] No se pudieron leer los certificados APNs:', err.message);
    return { sent: 0, error: 'certificados no disponibles' };
  }

  const client = http2.connect(APNS_HOST, {
    cert,
    key,
    passphrase: config.apns.passphrase || undefined,
  });

  const results = [];

  await Promise.all(
    tokens.map(
      (token) =>
        new Promise((resolve) => {
          const req = client.request({
            ':method': 'POST',
            ':path': `/3/device/${token}`,
            'apns-topic': config.apns.topic,
            'apns-push-type': 'background',
            'apns-priority': '5',
            'content-type': 'application/json',
          });

          let status = 0;
          let body = '';
          req.on('response', (headers) => {
            status = headers[':status'];
          });
          req.setEncoding('utf8');
          req.on('data', (chunk) => (body += chunk));
          req.on('end', () => {
            results.push({ token, status, body });
            resolve();
          });
          req.on('error', (err) => {
            results.push({ token, status: 0, error: err.message });
            resolve();
          });

          req.write(JSON.stringify({})); // payload vacio para passes
          req.end();
        }),
    ),
  );

  client.close();

  const sent = results.filter((r) => r.status === 200).length;
  if (sent < tokens.length) {
    console.warn('[apns] Algunas notificaciones fallaron:', results);
  }
  return { sent, results };
}
