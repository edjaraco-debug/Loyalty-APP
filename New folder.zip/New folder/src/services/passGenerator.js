import { PKPass } from '@walletpass/pass-js';
import fs from 'node:fs';
import { config } from '../config.js';

/**
 * Carga los certificados desde disco una sola vez.
 */
function loadCertificates() {
  return {
    wwdr: fs.readFileSync(config.certs.wwdr),
    signerCert: fs.readFileSync(config.certs.signerCert),
    signerKey: fs.readFileSync(config.certs.signerKey),
    signerKeyPassphrase: config.certs.signerKeyPassphrase || undefined,
  };
}

/**
 * Construye la barra de progreso visual de sellos. Ej: "●●●●●○○○○○"
 */
function barraDeProgreso(sellos, total) {
  const llenos = Math.min(sellos, total);
  return '●'.repeat(llenos) + '○'.repeat(Math.max(0, total - llenos));
}

/**
 * Genera el buffer de un archivo .pkpass para un cliente.
 * @param {object} pass - registro de la tabla passes
 * @param {object} [business] - cafeteria (tenant) con su marca. Si falta, usa los valores globales.
 * @returns {Promise<Buffer>}
 */
export async function generatePkpass(pass, business = null) {
  const certificates = loadCertificates();

  // Marca y reglas: por cafeteria si existe, si no los valores globales del .env
  const total = Number(business?.sellos_para_recompensa ?? config.sellosParaRecompensa);
  const organizationName = business?.organization_name ?? config.organizationName;
  const logoText = business?.logo_text ?? config.logoText;
  const backgroundColor = business?.background_color;
  const foregroundColor = business?.foreground_color;
  const labelColor = business?.label_color;

  const restantes = Math.max(0, total - (pass.sellos % total));

  const overrides = {
    // Datos que cambian por cliente
    serialNumber: pass.serial_number,
    authenticationToken: pass.auth_token,
    passTypeIdentifier: config.passTypeIdentifier,
    teamIdentifier: config.teamIdentifier,
    organizationName,
    logoText,
    webServiceURL: `${config.webServiceURL.replace(/\/$/, '')}/`,
  };
  // Colores de marca de la cafeteria (solo si estan definidos)
  if (backgroundColor) overrides.backgroundColor = backgroundColor;
  if (foregroundColor) overrides.foregroundColor = foregroundColor;
  if (labelColor) overrides.labelColor = labelColor;

  const pkpass = await PKPass.from(
    {
      model: config.paths.passModel,
      certificates,
    },
    overrides,
  );

  // Codigo QR escaneable en tienda (identifica al cliente)
  pkpass.setBarcodes({
    message: pass.serial_number,
    format: 'PKBarcodeFormatQR',
    messageEncoding: 'iso-8859-1',
    altText: pass.serial_number,
  });

  // --- Campos dinamicos ---
  // Header: sellos actuales
  pkpass.headerFields.push({
    key: 'sellos',
    label: 'SELLOS',
    value: `${pass.sellos % total}/${total}`,
    changeMessage: 'Tienes %@ sellos. Sigue asi!',
  });

  // Primario: barra de progreso
  pkpass.primaryFields.push({
    key: 'progreso',
    label: 'Tu progreso',
    value: barraDeProgreso(pass.sellos % total, total),
  });

  // Secundarios
  pkpass.secondaryFields.push(
    {
      key: 'cliente',
      label: 'Cliente',
      value: pass.customer_name,
    },
    {
      key: 'restantes',
      label: 'Te faltan',
      value: restantes === 0 ? 'Recompensa lista!' : `${restantes} cafe(s)`,
    },
  );

  // Auxiliares
  pkpass.auxiliaryFields.push(
    {
      key: 'nivel',
      label: 'Nivel',
      value: pass.nivel,
    },
    {
      key: 'recompensas',
      label: 'Cafes gratis ganados',
      value: String(pass.recompensas),
    },
  );

  return pkpass.getAsBuffer();
}
