import { customAlphabet } from 'nanoid';
import { one, many, exec } from './pool.js';
import { hashPassword } from '../security/passwords.js';

// ID de usuario legible: USR-XXXXXXXX
const userId = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8);

export const ROLES = Object.freeze({
  PLATFORM_OWNER: 'platform_owner',
  BUSINESS_OWNER: 'business_owner',
  BUSINESS_STAFF: 'business_staff',
});

const VALID_ROLES = new Set(Object.values(ROLES));
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function normEmail(email) {
  return String(email ?? '').trim().toLowerCase();
}

/** Quita el hash de la contrasena antes de exponer un usuario. */
export function publicUser(user) {
  if (!user) return user;
  const { password_hash, ...safe } = user;
  return safe;
}

/**
 * Crea una cuenta de usuario. La contrasena se guarda como hash scrypt.
 * @returns el usuario creado (sin el hash al exponerse mediante publicUser).
 */
export async function createUser({ businessId, email, password, name, role }) {
  const mail = normEmail(email);
  if (!EMAIL_RE.test(mail)) throw new Error('Email invalido.');
  if (!VALID_ROLES.has(role)) throw new Error('Rol invalido.');
  if (role === ROLES.PLATFORM_OWNER && businessId) {
    throw new Error('El operador de la plataforma no pertenece a una cafeteria.');
  }
  if (role !== ROLES.PLATFORM_OWNER && !businessId) {
    throw new Error('El usuario debe pertenecer a una cafeteria.');
  }
  if (await one('SELECT 1 FROM users WHERE email = $1', [mail])) {
    throw new Error('Ya existe un usuario con ese email.');
  }

  const id = `USR-${userId()}`;
  const passwordHash = await hashPassword(password);
  await exec(
    `INSERT INTO users (id, business_id, email, password_hash, name, role)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [id, businessId ?? null, mail, passwordHash, name ?? null, role],
  );
  return getUserById(id);
}

export function getUserById(id) {
  return one('SELECT * FROM users WHERE id = $1', [id]);
}

export function getUserByEmail(email) {
  return one('SELECT * FROM users WHERE email = $1', [normEmail(email)]);
}

/** Usuarios de una cafeteria (su personal). */
export function listUsers(businessId) {
  return many(
    'SELECT * FROM users WHERE business_id = $1 ORDER BY created_at DESC',
    [businessId],
  );
}

export async function countPlatformOwners() {
  const row = await one(`SELECT COUNT(*)::int AS n FROM users WHERE role = $1`, [
    ROLES.PLATFORM_OWNER,
  ]);
  return row.n;
}

export async function setUserPassword(id, password) {
  const passwordHash = await hashPassword(password);
  await exec('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, id]);
  return getUserById(id);
}

export async function updateUser(id, fields) {
  const sets = [];
  const values = [];
  let i = 1;
  if (typeof fields.name === 'string') {
    sets.push(`name = $${i++}`);
    values.push(fields.name.slice(0, 120));
  }
  if (fields.role !== undefined) {
    if (!VALID_ROLES.has(fields.role)) throw new Error('Rol invalido.');
    sets.push(`role = $${i++}`);
    values.push(fields.role);
  }
  if (fields.active !== undefined) {
    sets.push(`active = $${i++}`);
    values.push(fields.active ? true : false);
  }
  if (sets.length === 0) return getUserById(id);
  values.push(id);
  await exec(`UPDATE users SET ${sets.join(', ')} WHERE id = $${i}`, values);
  return getUserById(id);
}
