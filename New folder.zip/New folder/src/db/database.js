import { query, one, many, exec } from './pool.js';
import { encrypt, decrypt } from '../security/crypto.js';

/**
 * Descifra los campos PII (nombre, email) de una fila de pass antes de devolverla.
 */
function decryptPass(row) {
  if (!row) return row;
  return {
    ...row,
    customer_name: decrypt(row.customer_name),
    email: decrypt(row.email),
  };
}

export async function initSchema() {
  await query(`
    -- Cafeterias (tenants) de la plataforma SaaS
    CREATE TABLE IF NOT EXISTS businesses (
      id                     TEXT PRIMARY KEY,
      name                   TEXT NOT NULL,
      slug                   TEXT UNIQUE,
      organization_name      TEXT NOT NULL,
      logo_text              TEXT NOT NULL,
      background_color       TEXT NOT NULL DEFAULT 'rgb(74, 47, 28)',
      foreground_color       TEXT NOT NULL DEFAULT 'rgb(255, 244, 230)',
      label_color            TEXT NOT NULL DEFAULT 'rgb(214, 178, 130)',
      sellos_para_recompensa INTEGER NOT NULL DEFAULT 10,
      api_key_hash           TEXT NOT NULL UNIQUE,
      active                 BOOLEAN NOT NULL DEFAULT TRUE,
      created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    -- Cuentas de usuario para iniciar sesion (operador y personal de cafeterias)
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      business_id   TEXT REFERENCES businesses(id) ON DELETE CASCADE,
      email         TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      name          TEXT,
      role          TEXT NOT NULL,        -- platform_owner | business_owner | business_staff
      active        BOOLEAN NOT NULL DEFAULT TRUE,
      created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    -- Clientes y su tarjeta de fidelidad (cada uno pertenece a una cafeteria)
    CREATE TABLE IF NOT EXISTS passes (
      serial_number   TEXT PRIMARY KEY,
      business_id     TEXT REFERENCES businesses(id) ON DELETE CASCADE,
      customer_name   TEXT NOT NULL,
      email           TEXT,
      sellos          INTEGER NOT NULL DEFAULT 0,
      recompensas     INTEGER NOT NULL DEFAULT 0,
      nivel           TEXT NOT NULL DEFAULT 'Cafe Lover',
      auth_token      TEXT NOT NULL,
      created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    -- Dispositivos registrados por Apple Wallet para recibir actualizaciones
    CREATE TABLE IF NOT EXISTS registrations (
      device_library_id  TEXT NOT NULL,
      serial_number      TEXT NOT NULL REFERENCES passes(serial_number) ON DELETE CASCADE,
      push_token         TEXT NOT NULL,
      created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (device_library_id, serial_number)
    );

    CREATE INDEX IF NOT EXISTS idx_reg_serial ON registrations(serial_number);
    CREATE INDEX IF NOT EXISTS idx_passes_business ON passes(business_id);
    CREATE INDEX IF NOT EXISTS idx_users_business ON users(business_id);
  `);
}

// ---- Operaciones de passes ----

export async function createPass({ serialNumber, businessId, customerName, email, authToken }) {
  const row = await one(
    `INSERT INTO passes (serial_number, business_id, customer_name, email, auth_token)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [serialNumber, businessId ?? null, encrypt(customerName), encrypt(email ?? null), authToken],
  );
  return decryptPass(row);
}

export async function getPass(serialNumber) {
  const row = await one('SELECT * FROM passes WHERE serial_number = $1', [serialNumber]);
  return decryptPass(row);
}

// Obtiene un pass solo si pertenece a la cafeteria indicada (aislamiento de tenants)
export async function getBusinessPass(businessId, serialNumber) {
  const row = await one(
    'SELECT * FROM passes WHERE serial_number = $1 AND business_id = $2',
    [serialNumber, businessId],
  );
  return decryptPass(row);
}

export async function listPasses(businessId) {
  if (businessId) {
    const rows = await many(
      'SELECT * FROM passes WHERE business_id = $1 ORDER BY created_at DESC',
      [businessId],
    );
    return rows.map(decryptPass);
  }
  const rows = await many('SELECT * FROM passes ORDER BY created_at DESC');
  return rows.map(decryptPass);
}

export async function deletePass(serialNumber) {
  await exec('DELETE FROM passes WHERE serial_number = $1', [serialNumber]);
}

export async function updatePass(serialNumber, fields) {
  const allowed = ['sellos', 'recompensas', 'nivel', 'customer_name', 'email'];
  const encryptedFields = new Set(['customer_name', 'email']);
  const sets = [];
  const values = [];
  let i = 1;
  for (const [key, value] of Object.entries(fields)) {
    if (allowed.includes(key)) {
      // key proviene de una lista blanca fija: seguro para interpolar el nombre de columna
      sets.push(`${key} = $${i++}`);
      values.push(encryptedFields.has(key) ? encrypt(value) : value);
    }
  }
  if (sets.length === 0) return getPass(serialNumber);
  sets.push('updated_at = now()');
  values.push(serialNumber);
  await exec(`UPDATE passes SET ${sets.join(', ')} WHERE serial_number = $${i}`, values);
  return getPass(serialNumber);
}

export async function touchPass(serialNumber) {
  await exec('UPDATE passes SET updated_at = now() WHERE serial_number = $1', [serialNumber]);
  return getPass(serialNumber);
}

// ---- Operaciones de registros de dispositivos ----

export async function registerDevice({ deviceLibraryId, serialNumber, pushToken }) {
  await exec(
    `INSERT INTO registrations (device_library_id, serial_number, push_token)
     VALUES ($1, $2, $3)
     ON CONFLICT (device_library_id, serial_number)
     DO UPDATE SET push_token = EXCLUDED.push_token`,
    [deviceLibraryId, serialNumber, pushToken],
  );
}

export async function unregisterDevice({ deviceLibraryId, serialNumber }) {
  await exec(
    'DELETE FROM registrations WHERE device_library_id = $1 AND serial_number = $2',
    [deviceLibraryId, serialNumber],
  );
}

export async function getSerialsForDevice(deviceLibraryId, updatedSince) {
  if (updatedSince) {
    return many(
      `SELECT r.serial_number AS serial, p.updated_at AS "updatedAt"
       FROM registrations r
       JOIN passes p ON p.serial_number = r.serial_number
       WHERE r.device_library_id = $1 AND p.updated_at > $2::timestamptz`,
      [deviceLibraryId, updatedSince],
    );
  }
  return many(
    `SELECT r.serial_number AS serial, p.updated_at AS "updatedAt"
     FROM registrations r
     JOIN passes p ON p.serial_number = r.serial_number
     WHERE r.device_library_id = $1`,
    [deviceLibraryId],
  );
}

export async function getPushTokensForSerial(serialNumber) {
  const rows = await many(
    'SELECT push_token FROM registrations WHERE serial_number = $1',
    [serialNumber],
  );
  return rows.map((r) => r.push_token);
}
