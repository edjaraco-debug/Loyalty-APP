import pg from 'pg';
import { config } from '../config.js';

const { Pool } = pg;

// Pool de conexiones a PostgreSQL. Reutiliza conexiones entre peticiones.
export const pool = new Pool({
  connectionString: config.database.url,
  ssl: config.database.ssl,
  max: config.database.poolMax,
});

// Un error en una conexion inactiva no debe tumbar el proceso.
pool.on('error', (err) => {
  console.error('[db] Error inesperado en una conexion del pool:', err.message);
});

/** Ejecuta una consulta y devuelve el objeto resultado completo de pg. */
export function query(text, params) {
  return pool.query(text, params);
}

/** Devuelve la primera fila (o undefined). */
export async function one(text, params) {
  const result = await pool.query(text, params);
  return result.rows[0];
}

/** Devuelve todas las filas. */
export async function many(text, params) {
  const result = await pool.query(text, params);
  return result.rows;
}

/** Ejecuta una consulta sin necesitar el resultado (INSERT/UPDATE/DELETE). */
export async function exec(text, params) {
  await pool.query(text, params);
}

/**
 * Ejecuta una funcion dentro de una transaccion. Hace COMMIT si todo va bien
 * y ROLLBACK ante cualquier error.
 */
export async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/** Comprueba la conexion (util al arrancar). */
export async function ping() {
  await pool.query('SELECT 1');
}
