import { customAlphabet } from 'nanoid';
import { one, many, exec } from './pool.js';
import { randomToken, sha256Hex } from '../security/crypto.js';

// ID de cafeteria legible: BIZ-XXXXXXXX
const bizId = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8);

function slugify(name) {
  return String(name)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

/**
 * Crea una cafeteria (tenant) y devuelve sus datos junto con la API key en claro
 * (la API key solo se muestra una vez, despues solo se guarda su hash).
 */
export async function createBusiness({
  name,
  organizationName,
  logoText,
  backgroundColor,
  foregroundColor,
  labelColor,
  sellosParaRecompensa,
}) {
  const id = `BIZ-${bizId()}`;
  const apiKey = `sk_${randomToken(24)}`;
  const apiKeyHash = sha256Hex(apiKey);

  // Garantiza slug unico
  let slug = slugify(name) || id.toLowerCase();
  let suffix = 1;
  while (await one('SELECT 1 FROM businesses WHERE slug = $1', [slug])) {
    slug = `${slugify(name)}-${suffix++}`;
  }

  await exec(
    `INSERT INTO businesses (
      id, name, slug, organization_name, logo_text,
      background_color, foreground_color, label_color,
      sellos_para_recompensa, api_key_hash
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [
      id,
      name,
      slug,
      organizationName ?? name,
      logoText ?? name,
      backgroundColor ?? 'rgb(74, 47, 28)',
      foregroundColor ?? 'rgb(255, 244, 230)',
      labelColor ?? 'rgb(214, 178, 130)',
      Number(sellosParaRecompensa ?? 10),
      apiKeyHash,
    ],
  );

  return { business: await getBusiness(id), apiKey };
}

export function getBusiness(id) {
  return one('SELECT * FROM businesses WHERE id = $1', [id]);
}

export function getBusinessByApiKey(apiKey) {
  if (!apiKey) return Promise.resolve(undefined);
  return one(
    'SELECT * FROM businesses WHERE api_key_hash = $1 AND active = TRUE',
    [sha256Hex(apiKey)],
  );
}

export function listBusinesses() {
  return many('SELECT * FROM businesses ORDER BY created_at DESC');
}

export async function updateBusiness(id, fields) {
  const allowed = [
    'name',
    'organization_name',
    'logo_text',
    'background_color',
    'foreground_color',
    'label_color',
    'sellos_para_recompensa',
    'active',
  ];
  const sets = [];
  const values = [];
  let i = 1;
  for (const [key, value] of Object.entries(fields)) {
    if (allowed.includes(key)) {
      // key proviene de una lista blanca fija: seguro para interpolar
      sets.push(`${key} = $${i++}`);
      values.push(value);
    }
  }
  if (sets.length === 0) return getBusiness(id);
  values.push(id);
  await exec(`UPDATE businesses SET ${sets.join(', ')} WHERE id = $${i}`, values);
  return getBusiness(id);
}

/**
 * Regenera la API key de una cafeteria. Devuelve la nueva clave en claro.
 */
export async function rotateApiKey(id) {
  const apiKey = `sk_${randomToken(24)}`;
  await exec('UPDATE businesses SET api_key_hash = $1 WHERE id = $2', [sha256Hex(apiKey), id]);
  return apiKey;
}
