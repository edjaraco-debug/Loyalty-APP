import { Router } from 'express';
import { customAlphabet } from 'nanoid';
import {
  createPass,
  getBusinessPass,
  listPasses,
  updatePass,
} from '../db/database.js';
import { getBusinessByApiKey, getBusiness } from '../db/businesses.js';
import {
  createUser,
  listUsers,
  publicUser,
  updateUser,
  setUserPassword,
  getUserById,
  ROLES,
} from '../db/users.js';
import { authenticate } from '../security/auth.js';
import { generatePkpass } from '../services/passGenerator.js';
import { enqueuePush } from '../queue/pushQueue.js';
import { randomToken } from '../security/crypto.js';
import { ah } from '../lib/asyncHandler.js';

export const adminRouter = Router();

// Serial legible: CAFE-XXXXXXXX
const nanoid = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8);

// Formato valido de serial para evitar inyecciones por parametro
const SERIAL_RE = /^CAFE-[A-Z0-9]{8}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Niveles del programa segun cafes gratis ganados
function calcularNivel(recompensas) {
  if (recompensas >= 20) return 'Cafe Legend';
  if (recompensas >= 10) return 'Cafe Master';
  if (recompensas >= 5) return 'Cafe Pro';
  return 'Cafe Lover';
}

// Quita campos sensibles antes de responder
function publicPass(pass) {
  const { auth_token, ...safe } = pass;
  return safe;
}

// Autenticacion del panel: admite dos formas de acceso a una cafeteria.
//   1) Sesion de usuario (login):  Authorization: Bearer <token>
//   2) API key de la cafeteria:    x-api-key: <clave>  (integraciones/maquinas)
// En ambos casos se resuelve req.business (tenant) y req.access.role.
adminRouter.use(authenticate);
adminRouter.use(ah(async (req, res, next) => {
  // 1) Sesion de usuario perteneciente a una cafeteria
  if (req.user && req.user.business_id &&
      (req.user.role === ROLES.BUSINESS_OWNER || req.user.role === ROLES.BUSINESS_STAFF)) {
    const business = await getBusiness(req.user.business_id);
    if (!business || !business.active) return res.sendStatus(401);
    req.business = business;
    req.access = { via: 'session', role: req.user.role, userId: req.user.id };
    return next();
  }

  // 2) API key de la cafeteria (acceso completo al tenant, nivel propietario)
  const key = req.get('x-api-key') ?? '';
  const business = key ? await getBusinessByApiKey(key) : undefined;
  if (business) {
    req.business = business;
    req.access = { via: 'apiKey', role: ROLES.BUSINESS_OWNER, userId: null };
    return next();
  }

  return res.sendStatus(401);
}));

// Solo el propietario (o la API key) puede gestionar personal/marca.
function requireOwner(req, res, next) {
  if (req.access?.role !== ROLES.BUSINESS_OWNER) return res.sendStatus(403);
  next();
}

// Devuelve el pass solo si pertenece a la cafeteria autenticada
async function getOwnedPass(business, serial) {
  if (!SERIAL_RE.test(serial ?? '')) return null;
  return getBusinessPass(business.id, serial);
}

// Datos de la cafeteria autenticada
// GET /admin/me
adminRouter.get('/me', (req, res) => {
  const { api_key_hash, ...safe } = req.business;
  res.json(safe);
});

// Crear un nuevo cliente / tarjeta
// POST /admin/passes  { customerName, email }
adminRouter.post('/passes', ah(async (req, res) => {
  const customerName = typeof req.body?.customerName === 'string'
    ? req.body.customerName.trim()
    : '';
  const emailRaw = typeof req.body?.email === 'string' ? req.body.email.trim() : '';

  if (customerName.length < 1 || customerName.length > 80) {
    return res.status(400).json({ error: 'customerName es obligatorio (1-80 caracteres).' });
  }
  if (emailRaw && (emailRaw.length > 120 || !EMAIL_RE.test(emailRaw))) {
    return res.status(400).json({ error: 'email invalido.' });
  }

  const serialNumber = `CAFE-${nanoid()}`;
  const authToken = randomToken(20);

  const pass = await createPass({
    serialNumber,
    businessId: req.business.id,
    customerName,
    email: emailRaw || null,
    authToken,
  });
  res.status(201).json(publicPass(pass));
}));

// Listar clientes de la cafeteria autenticada (sin exponer auth_token)
adminRouter.get('/passes', ah(async (req, res) => {
  const passes = await listPasses(req.business.id);
  res.json(passes.map(publicPass));
}));

// Ver un cliente
adminRouter.get('/passes/:serial', ah(async (req, res) => {
  const pass = await getOwnedPass(req.business, req.params.serial);
  if (!pass) return res.sendStatus(404);
  res.json(publicPass(pass));
}));

// Sumar sellos (cada compra). Genera recompensa automatica al completar.
// POST /admin/passes/:serial/sellos  { cantidad: 1 }
adminRouter.post('/passes/:serial/sellos', ah(async (req, res) => {
  const pass = await getOwnedPass(req.business, req.params.serial);
  if (!pass) return res.sendStatus(404);

  const cantidad = Number(req.body?.cantidad ?? 1);
  if (!Number.isInteger(cantidad) || cantidad < 1 || cantidad > 20) {
    return res.status(400).json({ error: 'cantidad debe ser un entero entre 1 y 20.' });
  }
  const total = Number(req.business.sellos_para_recompensa);

  const acumulados = pass.sellos + cantidad;
  let recompensas = pass.recompensas;

  // Cada vez que se completa la tarjeta -> 1 cafe gratis
  let resto = acumulados;
  while (resto >= total) {
    resto -= total;
    recompensas += 1;
  }

  const nivel = calcularNivel(recompensas);
  const updated = await updatePass(pass.serial_number, {
    sellos: acumulados, // guardamos el acumulado total
    recompensas,
    nivel,
  });

  const push = await enqueuePush(pass.serial_number);
  res.json({ pass: publicPass(updated), push });
}));

// Canjear una recompensa (resta 1 cafe gratis)
// POST /admin/passes/:serial/canjear
adminRouter.post('/passes/:serial/canjear', ah(async (req, res) => {
  const pass = await getOwnedPass(req.business, req.params.serial);
  if (!pass) return res.sendStatus(404);
  if (pass.recompensas <= 0) {
    return res.status(400).json({ error: 'El cliente no tiene recompensas disponibles' });
  }
  const updated = await updatePass(pass.serial_number, {
    recompensas: pass.recompensas - 1,
  });
  const push = await enqueuePush(pass.serial_number);
  res.json({ pass: publicPass(updated), push });
}));

// Descargar el archivo .pkpass para entregarlo al cliente
// GET /admin/passes/:serial/download
adminRouter.get('/passes/:serial/download', ah(async (req, res) => {
  const pass = await getOwnedPass(req.business, req.params.serial);
  if (!pass) return res.sendStatus(404);
  try {
    const buffer = await generatePkpass(pass, req.business);
    res.set('Content-Type', 'application/vnd.apple.pkpass');
    res.set(
      'Content-Disposition',
      `attachment; filename="${pass.serial_number}.pkpass"`,
    );
    res.send(buffer);
  } catch (err) {
    console.error('[admin] Error generando pass:', err.message);
    res.status(500).json({ error: 'No se pudo generar la tarjeta.' });
  }
}));

// ---- Gestion de personal de la cafeteria (solo propietario) ----

// Listar el personal de la cafeteria
// GET /admin/staff
adminRouter.get('/staff', requireOwner, ah(async (req, res) => {
  const staff = await listUsers(req.business.id);
  res.json(staff.map(publicUser));
}));

// Crear una cuenta de personal (cajero) para la cafeteria
// POST /admin/staff  { email, password, name, role? }
adminRouter.post('/staff', requireOwner, ah(async (req, res) => {
  const { email, password, name } = req.body ?? {};
  const role = req.body?.role === ROLES.BUSINESS_OWNER
    ? ROLES.BUSINESS_OWNER
    : ROLES.BUSINESS_STAFF;
  try {
    const user = await createUser({
      businessId: req.business.id,
      email,
      password,
      name,
      role,
    });
    res.status(201).json(publicUser(user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}));

// Activar/desactivar o cambiar el rol de un miembro del personal
// PATCH /admin/staff/:userId  { active?, role? }
adminRouter.patch('/staff/:userId', requireOwner, ah(async (req, res) => {
  const target = await getUserById(req.params.userId);
  if (!target || target.business_id !== req.business.id) return res.sendStatus(404);

  const fields = {};
  if (req.body?.active !== undefined) fields.active = req.body.active;
  if (req.body?.role !== undefined) {
    if (req.body.role !== ROLES.BUSINESS_OWNER && req.body.role !== ROLES.BUSINESS_STAFF) {
      return res.status(400).json({ error: 'role debe ser business_owner o business_staff.' });
    }
    fields.role = req.body.role;
  }
  if (typeof req.body?.name === 'string') fields.name = req.body.name;

  try {
    const updated = await updateUser(req.params.userId, fields);
    res.json(publicUser(updated));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}));

// Restablecer la contrasena de un miembro del personal
// POST /admin/staff/:userId/password  { password }
adminRouter.post('/staff/:userId/password', requireOwner, ah(async (req, res) => {
  const target = await getUserById(req.params.userId);
  if (!target || target.business_id !== req.business.id) return res.sendStatus(404);
  try {
    await setUserPassword(req.params.userId, String(req.body?.password ?? ''));
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}));

