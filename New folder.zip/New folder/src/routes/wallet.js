import { Router } from 'express';
import { config } from '../config.js';
import {
  getPass,
  registerDevice,
  unregisterDevice,
  getSerialsForDevice,
} from '../db/database.js';
import { generatePkpass } from '../services/passGenerator.js';
import { safeEqual } from '../security/crypto.js';
import { getBusiness } from '../db/businesses.js';
import { ah } from '../lib/asyncHandler.js';

export const walletRouter = Router();

/**
 * Verifica el header "Authorization: ApplePass <token>" contra el token
 * del pass solicitado, usando comparacion resistente a timing attacks.
 */
function verifyAuth(req, pass) {
  if (!pass) return false;
  const header = req.get('Authorization') ?? '';
  const token = header.replace(/^ApplePass\s+/i, '').trim();
  if (token.length === 0) return false;
  return safeEqual(token, pass.auth_token);
}

// Registrar un dispositivo para recibir actualizaciones de un pass
// POST /v1/devices/:deviceLibraryId/registrations/:passTypeId/:serialNumber
walletRouter.post(
  '/v1/devices/:deviceLibraryId/registrations/:passTypeId/:serialNumber',
  ah(async (req, res) => {
    const { deviceLibraryId, passTypeId, serialNumber } = req.params;
    const pass = await getPass(serialNumber);

    if (!verifyAuth(req, pass)) return res.sendStatus(401);
    if (passTypeId !== config.passTypeIdentifier) return res.sendStatus(404);

    const pushToken = req.body?.pushToken;
    if (typeof pushToken !== 'string' || !/^[A-Za-z0-9]{32,200}$/.test(pushToken)) {
      return res.sendStatus(400);
    }

    await registerDevice({ deviceLibraryId, serialNumber, pushToken });
    // 201 si es nuevo registro (simplificado a 201 siempre que se inserta)
    return res.sendStatus(201);
  }),
);

// Dar de baja un dispositivo
// DELETE /v1/devices/:deviceLibraryId/registrations/:passTypeId/:serialNumber
walletRouter.delete(
  '/v1/devices/:deviceLibraryId/registrations/:passTypeId/:serialNumber',
  ah(async (req, res) => {
    const { deviceLibraryId, serialNumber } = req.params;
    const pass = await getPass(serialNumber);
    if (!verifyAuth(req, pass)) return res.sendStatus(401);

    await unregisterDevice({ deviceLibraryId, serialNumber });
    return res.sendStatus(200);
  }),
);

// Lista de seriales actualizables para un dispositivo
// GET /v1/devices/:deviceLibraryId/registrations/:passTypeId?passesUpdatedSince=TAG
walletRouter.get(
  '/v1/devices/:deviceLibraryId/registrations/:passTypeId',
  ah(async (req, res) => {
    const { deviceLibraryId, passTypeId } = req.params;
    if (passTypeId !== config.passTypeIdentifier) return res.sendStatus(404);

    const updatedSince = req.query.passesUpdatedSince;
    const rows = await getSerialsForDevice(deviceLibraryId, updatedSince);

    if (rows.length === 0) return res.sendStatus(204);

    // updated_at llega como Date desde PostgreSQL; lo pasamos a ISO para el tag.
    const lastUpdated = rows
      .map((r) => new Date(r.updatedAt).toISOString())
      .sort()
      .at(-1);

    return res.json({
      lastUpdated,
      serialNumbers: rows.map((r) => r.serial),
    });
  }),
);

// Entregar el pass actualizado
// GET /v1/passes/:passTypeId/:serialNumber
walletRouter.get('/v1/passes/:passTypeId/:serialNumber', ah(async (req, res) => {
  const { passTypeId, serialNumber } = req.params;
  const pass = await getPass(serialNumber);

  if (!verifyAuth(req, pass)) return res.sendStatus(401);
  if (passTypeId !== config.passTypeIdentifier) return res.sendStatus(404);

  const business = pass.business_id ? await getBusiness(pass.business_id) : null;
  const buffer = await generatePkpass(pass, business);
  res.set('Content-Type', 'application/vnd.apple.pkpass');
  res.set('Last-Modified', new Date(pass.updated_at).toUTCString());
  return res.send(buffer);
}));

// Log de errores que envia Apple Wallet (util para depurar)
// POST /v1/log
walletRouter.post('/v1/log', (req, res) => {
  if (Array.isArray(req.body?.logs)) {
    // Limita cantidad y longitud para evitar abuso/inundacion de logs
    for (const line of req.body.logs.slice(0, 20)) {
      console.log('[wallet-log]', String(line).slice(0, 500));
    }
  }
  return res.sendStatus(200);
});
