import { Router } from 'express';
import { config } from '../config.js';
import { safeEqual } from '../security/crypto.js';
import { authenticate } from '../security/auth.js';
import { createUser, ROLES, publicUser } from '../db/users.js';
import { ah } from '../lib/asyncHandler.js';
import {
  createBusiness,
  getBusiness,
  listBusinesses,
  updateBusiness,
  rotateApiKey,
} from '../db/businesses.js';

export const platformRouter = Router();

const COLOR_RE = /^rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)$/;

// Acceso de plataforma: clave maestra (x-platform-key) O sesion del operador.
platformRouter.use(authenticate);
platformRouter.use((req, res, next) => {
  const key = req.get('x-platform-key') ?? '';
  const byKey = key && safeEqual(key, config.platformAdminKey);
  const bySession = req.user?.role === ROLES.PLATFORM_OWNER;
  if (!byKey && !bySession) return res.sendStatus(401);
  next();
});

function validColor(value) {
  return value === undefined || (typeof value === 'string' && COLOR_RE.test(value));
}

// Quita el hash de la API key antes de exponer una cafeteria.
function stripBusiness(business) {
  if (!business) return business;
  const { api_key_hash, ...safe } = business;
  return safe;
}

// Alta de una cafeteria. Devuelve la API key UNA sola vez.
// Opcionalmente crea la cuenta del propietario (ownerEmail + ownerPassword).
// POST /platform/businesses
platformRouter.post('/businesses', ah(async (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  if (name.length < 1 || name.length > 80) {
    return res.status(400).json({ error: 'name es obligatorio (1-80 caracteres).' });
  }
  const {
    organizationName,
    logoText,
    backgroundColor,
    foregroundColor,
    labelColor,
    sellosParaRecompensa,
    ownerEmail,
    ownerPassword,
    ownerName,
  } = req.body ?? {};

  if (!validColor(backgroundColor) || !validColor(foregroundColor) || !validColor(labelColor)) {
    return res.status(400).json({ error: 'Los colores deben tener formato rgb(r, g, b).' });
  }
  const sellos = Number(sellosParaRecompensa ?? 10);
  if (!Number.isInteger(sellos) || sellos < 1 || sellos > 50) {
    return res.status(400).json({ error: 'sellosParaRecompensa debe ser un entero entre 1 y 50.' });
  }

  // Si se pide crear el propietario, validamos antes de crear la cafeteria.
  const wantsOwner = ownerEmail !== undefined || ownerPassword !== undefined;
  if (wantsOwner && (typeof ownerPassword !== 'string' || ownerPassword.length < 8)) {
    return res.status(400).json({ error: 'ownerPassword debe tener al menos 8 caracteres.' });
  }

  const { business, apiKey } = await createBusiness({
    name,
    organizationName,
    logoText,
    backgroundColor,
    foregroundColor,
    labelColor,
    sellosParaRecompensa: sellos,
  });

  let owner = null;
  if (wantsOwner) {
    try {
      owner = await createUser({
        businessId: business.id,
        email: ownerEmail,
        password: ownerPassword,
        name: ownerName,
        role: ROLES.BUSINESS_OWNER,
      });
    } catch (err) {
      // La cafeteria quedo creada; informamos del problema con la cuenta.
      return res.status(201).json({
        business: stripBusiness(business),
        apiKey,
        owner: null,
        avisoOwner: `No se pudo crear la cuenta del propietario: ${err.message}`,
        aviso: 'Guarda esta apiKey ahora. No se volvera a mostrar.',
      });
    }
  }

  res.status(201).json({
    business: stripBusiness(business),
    apiKey,
    owner: owner ? publicUser(owner) : null,
    aviso: 'Guarda esta apiKey ahora. No se volvera a mostrar.',
  });
}));

// Listar cafeterias (sin exponer el hash de la clave)
platformRouter.get('/businesses', ah(async (_req, res) => {
  const businesses = await listBusinesses();
  res.json(businesses.map(stripBusiness));
}));

// Ver una cafeteria
platformRouter.get('/businesses/:id', ah(async (req, res) => {
  const business = await getBusiness(req.params.id);
  if (!business) return res.sendStatus(404);
  res.json(stripBusiness(business));
}));

// Actualizar marca/reglas de una cafeteria
// PATCH /platform/businesses/:id
platformRouter.patch('/businesses/:id', ah(async (req, res) => {
  const business = await getBusiness(req.params.id);
  if (!business) return res.sendStatus(404);

  const fields = {};
  const map = {
    name: 'name',
    organizationName: 'organization_name',
    logoText: 'logo_text',
    backgroundColor: 'background_color',
    foregroundColor: 'foreground_color',
    labelColor: 'label_color',
    sellosParaRecompensa: 'sellos_para_recompensa',
    active: 'active',
  };
  for (const [inKey, col] of Object.entries(map)) {
    if (req.body?.[inKey] === undefined) continue;
    const value = req.body[inKey];
    if (col.endsWith('color') && !validColor(value)) {
      return res.status(400).json({ error: `${inKey} invalido (formato rgb).` });
    }
    if (col === 'sellos_para_recompensa') {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 1 || n > 50) {
        return res.status(400).json({ error: 'sellosParaRecompensa entre 1 y 50.' });
      }
      fields[col] = n;
    } else if (col === 'active') {
      fields[col] = Boolean(value);
    } else {
      fields[col] = String(value).slice(0, 120);
    }
  }

  const updated = await updateBusiness(req.params.id, fields);
  res.json(stripBusiness(updated));
}));

// Rotar la API key de una cafeteria
// POST /platform/businesses/:id/rotate-key
platformRouter.post('/businesses/:id/rotate-key', ah(async (req, res) => {
  const business = await getBusiness(req.params.id);
  if (!business) return res.sendStatus(404);
  const apiKey = await rotateApiKey(req.params.id);
  res.json({ apiKey, aviso: 'La clave anterior dejo de funcionar.' });
}));
