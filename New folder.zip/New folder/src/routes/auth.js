import { Router } from 'express';
import { getUserByEmail, publicUser } from '../db/users.js';
import { verifyPassword, DUMMY_HASH } from '../security/passwords.js';
import { signToken } from '../security/tokens.js';
import { authenticate, requireAuth } from '../security/auth.js';
import { ah } from '../lib/asyncHandler.js';

export const authRouter = Router();

// Inicio de sesion. Devuelve un token de sesion (Bearer) valido 12 horas.
// POST /auth/login  { email, password }
authRouter.post('/login', ah(async (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  const user = await getUserByEmail(email);
  // Verificamos siempre (con un hash ficticio si no existe) para no filtrar
  // si el email esta registrado ni por la respuesta ni por el tiempo de respuesta.
  const ok = await verifyPassword(password, user?.active ? user.password_hash : DUMMY_HASH);

  if (!user || !user.active || !ok) {
    return res.status(401).json({ error: 'Credenciales invalidas.' });
  }

  const token = signToken({ sub: user.id, role: user.role, biz: user.business_id });
  res.json({ token, tokenType: 'Bearer', expiresIn: 60 * 60 * 12, user: publicUser(user) });
}));

// Datos del usuario autenticado.
// GET /auth/me   (Authorization: Bearer <token>)
authRouter.get('/me', authenticate, requireAuth, (req, res) => {
  res.json(publicUser(req.user));
});

// Cierre de sesion. Con tokens sin estado, el cliente solo descarta el token.
// POST /auth/logout
authRouter.post('/logout', (_req, res) => {
  res.json({ ok: true, mensaje: 'Descarta el token en el cliente para cerrar sesion.' });
});
