import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT_DIR = path.resolve(__dirname, '..');

function required(name, fallback) {
  const value = process.env[name] ?? fallback;
  if (value === undefined || value === '') {
    console.warn(`[config] Falta la variable de entorno ${name}. Revisa tu archivo .env`);
  }
  return value;
}

const NODE_ENV = process.env.NODE_ENV ?? 'development';
const IS_PROD = NODE_ENV === 'production';

// Valores por defecto inseguros que NO deben usarse en produccion
const INSECURE_DEFAULTS = new Set([
  'token_demo_inseguro',
  'admin_demo_inseguro',
  'cambia_esto_por_un_token_secreto',
  'cambia_esto_por_una_clave_admin',
  'platform_demo_inseguro',
  'cambia_esto_por_una_clave_de_plataforma',
  '',
]);

export const config = {
  nodeEnv: NODE_ENV,
  isProd: IS_PROD,
  port: Number(process.env.PORT ?? 3000),
  // Detras de un proxy/balanceador (Nginx, Render, etc.) para rate limiting e IPs reales
  trustProxy: process.env.TRUST_PROXY === 'true',
  webServiceURL: required('WEB_SERVICE_URL', 'https://localhost:3000'),

  passTypeIdentifier: required('PASS_TYPE_IDENTIFIER'),
  teamIdentifier: required('TEAM_IDENTIFIER'),

  organizationName: required('ORGANIZATION_NAME', 'Mi Cafeteria'),
  logoText: process.env.LOGO_TEXT ?? 'Mi Cafeteria',

  sellosParaRecompensa: Number(process.env.SELLOS_PARA_RECOMPENSA ?? 10),

  certs: {
    signerCert: path.resolve(ROOT_DIR, process.env.PASS_CERT_PATH ?? './certs/signerCert.pem'),
    signerKey: path.resolve(ROOT_DIR, process.env.PASS_KEY_PATH ?? './certs/signerKey.pem'),
    signerKeyPassphrase: process.env.PASS_KEY_PASSPHRASE ?? '',
    wwdr: path.resolve(ROOT_DIR, process.env.WWDR_CERT_PATH ?? './certs/wwdr.pem'),
  },

  apns: {
    keyPath: path.resolve(ROOT_DIR, process.env.APNS_KEY_PATH ?? './certs/signerKey.pem'),
    certPath: path.resolve(ROOT_DIR, process.env.APNS_CERT_PATH ?? './certs/signerCert.pem'),
    passphrase: process.env.PASS_KEY_PASSPHRASE ?? '',
    // El topic de APNs para passes es el propio Pass Type Identifier
    topic: required('PASS_TYPE_IDENTIFIER'),
  },

  authenticationToken: required('AUTHENTICATION_TOKEN', 'token_demo_inseguro'),
  adminApiKey: required('ADMIN_API_KEY', 'admin_demo_inseguro'),
  // Clave maestra del operador SaaS para dar de alta cafeterias
  platformAdminKey: required('PLATFORM_ADMIN_KEY', 'platform_demo_inseguro'),

  // --- Base de datos PostgreSQL ---
  database: {
    // Cadena de conexion completa, ej:
    //   postgres://usuario:password@host:5432/basededatos
    url: required('DATABASE_URL', 'postgres://postgres:postgres@localhost:5432/fidelidad'),
    // SSL para bases gestionadas (Render, Supabase, Neon, RDS...). Pon PGSSL=true.
    ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
    // Tamano maximo del pool de conexiones
    poolMax: Number(process.env.PG_POOL_MAX ?? 10),
  },

  // --- Cola de notificaciones push (BullMQ + Redis) ---
  redis: {
    // Cadena de conexion a Redis, ej: redis://localhost:6379
    // Si esta vacia, los push se envian directos (modo simple, no escalable).
    url: process.env.REDIS_URL ?? '',
    // Cuantos push procesa el worker a la vez
    workerConcurrency: Number(process.env.PUSH_WORKER_CONCURRENCY ?? 5),
    // Si es "true", el servidor web tambien procesa la cola (util en desarrollo).
    // En produccion conviene dejarlo en "false" y correr `npm run worker` aparte.
    runWorkerInline: process.env.START_WORKER === 'true',
  },

  security: {
    // Clave de 32 bytes (64 hex) para cifrar PII en reposo (AES-256-GCM)
    encryptionKey: process.env.ENCRYPTION_KEY ?? '',
    // Secreto para firmar los tokens de sesion (login). Minimo 32 caracteres.
    sessionSecret: process.env.JWT_SECRET ?? '',
    // Rate limiting (peticiones por ventana de tiempo por IP)
    rateLimit: {
      windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60_000),
      walletMax: Number(process.env.RATE_LIMIT_WALLET_MAX ?? 120),
      adminMax: Number(process.env.RATE_LIMIT_ADMIN_MAX ?? 60),
    },
  },

  paths: {
    root: ROOT_DIR,
    data: path.resolve(ROOT_DIR, 'data'),
    passModel: path.resolve(ROOT_DIR, 'passModels', 'fidelidad.pass'),
    output: path.resolve(ROOT_DIR, 'data', 'output'),
  },
};

/**
 * Verifica que la configuracion sea segura. En produccion aborta el arranque
 * si detecta secretos por defecto o falta la clave de cifrado.
 */
export function validateSecurity() {
  const problems = [];

  if (!/^[0-9a-fA-F]{64}$/.test(config.security.encryptionKey)) {
    problems.push(
      'ENCRYPTION_KEY ausente o invalida (debe ser 64 caracteres hex). ' +
        'Genera una con: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"',
    );
  }
  if (INSECURE_DEFAULTS.has(config.authenticationToken)) {
    problems.push('AUTHENTICATION_TOKEN usa un valor por defecto inseguro.');
  }
  if (INSECURE_DEFAULTS.has(config.adminApiKey)) {
    problems.push('ADMIN_API_KEY usa un valor por defecto inseguro.');
  }
  if (INSECURE_DEFAULTS.has(config.platformAdminKey)) {
    problems.push('PLATFORM_ADMIN_KEY usa un valor por defecto inseguro.');
  }
  if (!config.security.sessionSecret || config.security.sessionSecret.length < 32) {
    problems.push(
      'JWT_SECRET ausente o demasiado corto (minimo 32 caracteres). ' +
        'Genera uno con: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"',
    );
  }
  if (config.isProd && !config.webServiceURL.startsWith('https://')) {
    problems.push('WEB_SERVICE_URL debe usar HTTPS en produccion.');
  }
  if (config.isProd && /localhost|127\.0\.0\.1/.test(config.database.url)) {
    problems.push('DATABASE_URL apunta a localhost en produccion. Usa tu base gestionada.');
  }

  if (problems.length > 0) {
    const msg = '[seguridad] Problemas de configuracion:\n  - ' + problems.join('\n  - ');
    if (config.isProd) {
      throw new Error(msg + '\nArranque abortado en produccion por seguridad.');
    }
    console.warn(msg + '\n(En desarrollo solo es una advertencia.)');
  }
}
