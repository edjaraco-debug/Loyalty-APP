import { initSchema } from '../db/database.js';
import { createUser, countPlatformOwners, ROLES } from '../db/users.js';
import { pool } from '../db/pool.js';

// Crea la cuenta del operador de la plataforma (platform_owner).
// Uso:
//   node src/scripts/createPlatformOwner.js correo@dominio.com "MiContrasena"
// o definiendo PLATFORM_OWNER_EMAIL y PLATFORM_OWNER_PASSWORD en el .env
async function main() {
  await initSchema();

  const email = process.argv[2] ?? process.env.PLATFORM_OWNER_EMAIL;
  const password = process.argv[3] ?? process.env.PLATFORM_OWNER_PASSWORD;
  const name = process.argv[4] ?? process.env.PLATFORM_OWNER_NAME ?? 'Operador';

  if (!email || !password) {
    console.error(
      'Faltan datos. Uso: node src/scripts/createPlatformOwner.js <email> <password> [nombre]',
    );
    process.exit(1);
  }

  if ((await countPlatformOwners()) > 0) {
    console.log('Ya existe al menos un operador de plataforma. No se creo otro.');
    console.log('Si necesitas otro, crealo manualmente con cuidado.');
    await pool.end();
    return;
  }

  const user = await createUser({
    email,
    password,
    name,
    role: ROLES.PLATFORM_OWNER,
  });

  console.log('Operador de plataforma creado:');
  console.log('  email:', user.email);
  console.log('  id:   ', user.id);
  console.log('Inicia sesion con POST /auth/login para obtener tu token.');
  await pool.end();
}

main().catch((err) => {
  console.error('Error creando el operador:', err.message);
  process.exit(1);
});
