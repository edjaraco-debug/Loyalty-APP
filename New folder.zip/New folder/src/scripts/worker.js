import { config } from '../config.js';
import { startPushWorker } from '../queue/pushWorker.js';

// Proceso independiente que solo procesa la cola de push.
// Levanta tantos como necesites para repartir la carga.
if (!config.redis.url) {
  console.error(
    'No hay REDIS_URL configurado. El worker necesita Redis para funcionar.',
  );
  process.exit(1);
}

console.log('[worker] Worker de push iniciado. Esperando trabajos...');
const worker = startPushWorker();

// Apagado limpio (Ctrl+C / SIGTERM del orquestador).
async function shutdown(signal) {
  console.log(`[worker] ${signal} recibido, cerrando...`);
  await worker.close();
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
