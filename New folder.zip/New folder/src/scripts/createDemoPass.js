import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { initSchema, createPass, updatePass, getPass } from '../db/database.js';
import { createBusiness, getBusiness } from '../db/businesses.js';
import { pool } from '../db/pool.js';
import { generatePkpass } from '../services/passGenerator.js';
import { randomToken } from '../security/crypto.js';

// Crea una cafeteria demo + un cliente de prueba y guarda su .pkpass en data/output/
async function main() {
  await initSchema();

  // Cafeteria demo (tenant)
  const DEMO_BIZ_ID = 'BIZ-DEMO0001';
  let business = await getBusiness(DEMO_BIZ_ID);
  let apiKey;
  if (!business) {
    const created = await createBusiness({
      name: 'Cafeteria Demo',
      organizationName: 'Cafeteria Demo',
      logoText: 'Cafeteria Demo',
      backgroundColor: 'rgb(74, 47, 28)',
      foregroundColor: 'rgb(255, 244, 230)',
      labelColor: 'rgb(214, 178, 130)',
      sellosParaRecompensa: 10,
    });
    business = created.business;
    apiKey = created.apiKey;
    console.log('Cafeteria demo creada. API key (guardala):', apiKey);
  }

  const serialNumber = 'CAFE-DEMO0001';
  let pass = await getPass(serialNumber);
  if (!pass) {
    pass = await createPass({
      serialNumber,
      businessId: business.id,
      customerName: 'Cliente Demo',
      email: 'demo@tucafeteria.com',
      authToken: randomToken(20),
    });
  }

  // Sumamos algunos sellos de ejemplo
  pass = await updatePass(serialNumber, { sellos: 7, recompensas: 1, nivel: 'Cafe Lover' });

  const buffer = await generatePkpass(pass, business);

  fs.mkdirSync(config.paths.output, { recursive: true });
  const outPath = path.join(config.paths.output, `${serialNumber}.pkpass`);
  fs.writeFileSync(outPath, buffer);

  console.log('Tarjeta demo generada en:', outPath);
  console.log('Arrastra ese archivo al Simulator de iOS o abrelo en un Mac para probarlo.');
  await pool.end();
}

main().catch((err) => {
  console.error('Error generando la tarjeta demo:', err);
  process.exit(1);
});
