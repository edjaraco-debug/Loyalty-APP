import { initSchema } from '../db/database.js';
import { pool } from '../db/pool.js';

async function main() {
  await initSchema();
  console.log('Base de datos inicializada correctamente.');
  await pool.end();
}

main().catch((err) => {
  console.error('Error inicializando la base de datos:', err.message);
  process.exit(1);
});
