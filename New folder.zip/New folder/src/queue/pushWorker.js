import { Worker } from 'bullmq';
import { config } from '../config.js';
import { getRedisConnection } from './connection.js';
import { pushUpdateForSerial } from '../services/apns.js';
import { PUSH_QUEUE_NAME } from './pushQueue.js';

/**
 * Arranca un worker que consume la cola "push" y envia las notificaciones
 * a APNs. Si APNs devuelve un error, lanza una excepcion para que BullMQ
 * reintente el trabajo segun la politica de la cola.
 *
 * Puede correr dentro del servidor web (START_WORKER=true) o como proceso
 * independiente con `npm run worker` para escalar horizontalmente.
 */
export function startPushWorker() {
  const worker = new Worker(
    PUSH_QUEUE_NAME,
    async (job) => {
      const { serialNumber } = job.data;
      const result = await pushUpdateForSerial(serialNumber);
      if (result.error) {
        // Forzamos el reintento de BullMQ.
        throw new Error(result.error);
      }
      return result;
    },
    {
      connection: getRedisConnection(),
      concurrency: config.redis.workerConcurrency,
    },
  );

  worker.on('completed', (job, result) => {
    console.log(
      `[push] Job ${job.id} ok (${result?.sent ?? 0} dispositivos notificados).`,
    );
  });

  worker.on('failed', (job, err) => {
    console.warn(`[push] Job ${job?.id} fallo: ${err.message}`);
  });

  worker.on('error', (err) => {
    console.error('[push] Error del worker:', err.message);
  });

  return worker;
}
