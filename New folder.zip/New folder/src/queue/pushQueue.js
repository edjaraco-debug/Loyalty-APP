import { Queue } from 'bullmq';
import { config } from '../config.js';
import { getRedisConnection } from './connection.js';
import { pushUpdateForSerial } from '../services/apns.js';

export const PUSH_QUEUE_NAME = 'push';

let queue = null;

// Hay cola solo si Redis esta configurado.
export function isQueueEnabled() {
  return Boolean(config.redis.url);
}

// Devuelve (creando si hace falta) la cola de BullMQ.
export function getPushQueue() {
  if (!isQueueEnabled()) return null;
  if (!queue) {
    queue = new Queue(PUSH_QUEUE_NAME, {
      connection: getRedisConnection(),
      defaultJobOptions: {
        // Reintenta hasta 5 veces con espera creciente si APNs falla.
        attempts: 5,
        backoff: { type: 'exponential', delay: 2000 },
        // Limpia el historial para no llenar Redis.
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    });
  }
  return queue;
}

/**
 * Encola (o envia directo) una actualizacion push para un pass.
 *
 * - Con Redis: agrega un trabajo a la cola y responde al instante. El worker
 *   se encarga de hablar con APNs en segundo plano, con reintentos.
 * - Sin Redis: envia directamente (modo simple, util en desarrollo).
 */
export async function enqueuePush(serialNumber) {
  if (!isQueueEnabled()) {
    try {
      const result = await pushUpdateForSerial(serialNumber);
      return { queued: false, ...result };
    } catch (err) {
      console.error('[push] Error enviando push directo:', err.message);
      return { queued: false, sent: 0, error: err.message };
    }
  }

  const q = getPushQueue();
  // Agrupamos por serial: si ya hay un push pendiente para el mismo pass,
  // no tiene sentido encolar otro identico mientras espera.
  const job = await q.add(
    'update',
    { serialNumber },
    { jobId: `push:${serialNumber}` },
  ).catch(async (err) => {
    // jobId duplicado -> ya hay uno encolado para este serial; lo ignoramos.
    if (String(err.message).includes('already exists')) return null;
    throw err;
  });

  return { queued: true, jobId: job?.id ?? `push:${serialNumber}` };
}

// Cierra la cola (apagado limpio).
export async function closePushQueue() {
  if (queue) {
    await queue.close();
    queue = null;
  }
}
