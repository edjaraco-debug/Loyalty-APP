import IORedis from 'ioredis';
import { config } from '../config.js';

// Conexion a Redis compartida por la cola (productor) y el worker (consumidor).
// BullMQ exige `maxRetriesPerRequest: null` para que los comandos bloqueantes
// del worker funcionen correctamente.
let connection = null;

export function getRedisConnection() {
  if (!config.redis.url) {
    throw new Error('REDIS_URL no esta configurado. No se puede conectar a Redis.');
  }
  if (!connection) {
    connection = new IORedis(config.redis.url, {
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
    });
    connection.on('error', (err) => {
      console.error('[redis] Error de conexion:', err.message);
    });
  }
  return connection;
}

// Cierra la conexion (para apagados limpios o scripts puntuales).
export async function closeRedisConnection() {
  if (connection) {
    await connection.quit();
    connection = null;
  }
}
