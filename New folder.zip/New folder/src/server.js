import express from 'express';
import { config, validateSecurity } from './config.js';
import { initSchema } from './db/database.js';
import { ping } from './db/pool.js';
import { isQueueEnabled } from './queue/pushQueue.js';
import { startPushWorker } from './queue/pushWorker.js';
import { walletRouter } from './routes/wallet.js';
import { adminRouter } from './routes/admin.js';
import { platformRouter } from './routes/platform.js';
import { authRouter } from './routes/auth.js';
import {
  securityHeaders,
  walletLimiter,
  adminLimiter,
  enforceHttps,
} from './security/middleware.js';

// Aborta el arranque en produccion si la configuracion no es segura
validateSecurity();

const app = express();

// No revelar el framework
app.disable('x-powered-by');

// IPs reales y HTTPS correcto detras de un proxy/balanceador
if (config.trustProxy) {
  app.set('trust proxy', 1);
}

// Cabeceras de seguridad y HTTPS obligatorio en produccion
app.use(securityHeaders);
app.use(enforceHttps);

// Apple Wallet envia JSON; limitamos el tamano del cuerpo para evitar abuso.
app.use(express.json({ type: ['application/json', 'text/json'], limit: '64kb' }));

// Endpoint de salud
app.get('/', (_req, res) => {
  res.json({ status: 'ok', service: 'cafeteria-wallet-fidelidad' });
});

// Protocolo de Apple Wallet (registro/actualizacion de passes)
app.use('/', walletLimiter, walletRouter);

// Inicio de sesion (operador y personal de cafeterias)
app.use('/auth', adminLimiter, authRouter);

// Panel de administracion por cafeteria (crear clientes, sumar sellos, descargar)
app.use('/admin', adminLimiter, adminRouter);

// Panel de la plataforma SaaS (alta y gestion de cafeterias). Solo el operador.
app.use('/platform', adminLimiter, platformRouter);

app.use((req, res) => res.sendStatus(404));

// Manejador de errores: no filtra detalles internos al cliente
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error('[error]', err.message);
  if (res.headersSent) return;
  res.status(err.type === 'entity.too.large' ? 413 : 500).json({ error: 'Error interno.' });
});

// Red de seguridad: evita que una promesa rechazada tumbe el proceso sin rastro
process.on('unhandledRejection', (reason) => {
  console.error('[unhandledRejection]', reason);
});

async function bootstrap() {
  // Verifica la conexion a PostgreSQL antes de aceptar trafico
  await ping();
  // Crea las tablas si no existen
  await initSchema();

  // Cola de push: avisamos en que modo trabaja.
  if (isQueueEnabled()) {
    console.log('Cola de push: Redis activo (envios en segundo plano).');
    if (config.redis.runWorkerInline) {
      startPushWorker();
      console.log('Worker de push corriendo dentro del servidor (START_WORKER=true).');
    } else {
      console.log('Recuerda arrancar el worker aparte con: npm run worker');
    }
  } else {
    console.log('Cola de push: sin Redis, los push se envian directos (modo simple).');
  }

  app.listen(config.port, () => {
    console.log(`Servidor de fidelidad escuchando en puerto ${config.port}`);
    console.log(`Entorno: ${config.nodeEnv}`);
    console.log(`Pass Type ID: ${config.passTypeIdentifier}`);
    console.log(`Web Service URL: ${config.webServiceURL}`);
  });
}

bootstrap().catch((err) => {
  console.error('No se pudo iniciar el servidor:', err.message);
  process.exit(1);
});
