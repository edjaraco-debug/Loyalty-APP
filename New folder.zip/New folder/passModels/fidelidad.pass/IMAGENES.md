# Imagenes del modelo de pass (.pass)

Coloca aqui las imagenes de tu marca. Son obligatorias para que Apple Wallet
acepte el pass. Usa PNG sin transparencia para los iconos.

## Archivos requeridos

| Archivo            | Tamano (px) | Descripcion                                  |
|--------------------|-------------|----------------------------------------------|
| icon.png           | 29 x 29     | Icono (notificaciones, emails)               |
| icon@2x.png        | 58 x 58     | Icono retina                                 |
| icon@3x.png        | 87 x 87     | Icono super retina                           |
| logo.png           | 160 x 50    | Logo arriba a la izquierda de la tarjeta     |
| logo@2x.png        | 320 x 100   | Logo retina                                  |
| logo@3x.png        | 480 x 150   | Logo super retina                            |

## Imagenes opcionales (recomendadas)

| Archivo            | Tamano (px) | Descripcion                                  |
|--------------------|-------------|----------------------------------------------|
| strip.png          | 375 x 144   | Banner detras de los campos                   |
| strip@2x.png       | 750 x 288   | Banner retina                                 |
| strip@3x.png       | 1125 x 432  | Banner super retina                           |

> Si usas strip image, el campo primario (la barra de progreso) se mostrara
> encima de la imagen, asi que elige una imagen que no compita con el texto.

## Como generar rapido los iconos

Si tienes un logo cuadrado `logo-cuadrado.png`, puedes generar los tamanos con
ImageMagick:

```bash
magick logo-cuadrado.png -resize 29x29   icon.png
magick logo-cuadrado.png -resize 58x58   icon@2x.png
magick logo-cuadrado.png -resize 87x87   icon@3x.png
```
