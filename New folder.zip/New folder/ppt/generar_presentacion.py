"""
Genera una presentacion PowerPoint que muestra como se ve y se usa la
app de tarjeta de fidelidad para Apple Wallet.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ---- Paleta de marca (cafeteria) ----
CAFE_OSCURO = RGBColor(0x4A, 0x2F, 0x1C)   # marron oscuro
CAFE_MEDIO = RGBColor(0x6F, 0x4E, 0x37)    # marron cafe
CREMA = RGBColor(0xFF, 0xF4, 0xE6)         # crema
DORADO = RGBColor(0xD6, 0xB2, 0x82)        # dorado/latte
VERDE = RGBColor(0x2E, 0x7D, 0x32)         # verde acento
BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
GRIS = RGBColor(0x66, 0x66, 0x66)
GRIS_CLARO = RGBColor(0xEE, 0xE8, 0xE0)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
SW = prs.slide_width
SH = prs.slide_height
BLANK = prs.slide_layouts[6]


def add_slide():
    return prs.slides.add_slide(BLANK)


def fill_bg(slide, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, SH)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    s.line.fill.background()
    s.shadow.inherit = False
    slide.shapes._spTree.remove(s._element)
    slide.shapes._spTree.insert(2, s._element)
    return s


def box(slide, left, top, width, height, fill=None, line=None,
        shape=MSO_SHAPE.RECTANGLE, line_w=Pt(1)):
    s = slide.shapes.add_shape(shape, left, top, width, height)
    if fill is None:
        s.fill.background()
    else:
        s.fill.solid()
        s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = line_w
    s.shadow.inherit = False
    return s


def text(slide, left, top, width, height, runs, align=PP_ALIGN.LEFT,
         anchor=MSO_ANCHOR.TOP, wrap=True):
    """runs: lista de (texto, tamano, color, bold) o lista de parrafos."""
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = Pt(4)
    tf.margin_right = Pt(4)
    tf.margin_top = Pt(2)
    tf.margin_bottom = Pt(2)
    if isinstance(runs[0], tuple):
        runs = [runs]
    for i, para in enumerate(runs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        for (t, size, color, bold) in para:
            r = p.add_run()
            r.text = t
            r.font.size = Pt(size)
            r.font.color.rgb = color
            r.font.bold = bold
            r.font.name = "Segoe UI"
    return tb


# =====================================================================
# SLIDE 1 - PORTADA
# =====================================================================
s = add_slide()
fill_bg(s, CAFE_OSCURO)
# franja dorada
box(s, 0, Inches(5.4), SW, Inches(0.12), fill=DORADO)
# icono taza
cup = box(s, Inches(0.9), Inches(2.4), Inches(1.7), Inches(1.7),
          fill=DORADO, shape=MSO_SHAPE.OVAL)
text(s, Inches(0.9), Inches(2.55), Inches(1.7), Inches(1.4),
     [[("\u2615", 60, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER,
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(3.0), Inches(2.1), Inches(9.4), Inches(1.4),
     [[("Tarjeta de Fidelidad", 44, BLANCO, True)],
      [("para Apple Wallet", 44, DORADO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(3.05), Inches(3.7), Inches(9.4), Inches(1.0),
     [[("Como se ve y como se usa la app de tu cafeteria", 20, CREMA, False)]])
text(s, Inches(0.9), Inches(6.4), Inches(11), Inches(0.6),
     [[("Cafe para llevar  \u00b7  Programa \"10 sellos = 1 cafe gratis\"  \u00b7  Junio 2026",
        14, DORADO, False)]])

# =====================================================================
# SLIDE 2 - QUE ES
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("\u00bfQue es esta app?", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

text(s, Inches(0.6), Inches(1.4), Inches(12), Inches(0.9),
     [[("Una tarjeta de fidelidad digital que tus clientes guardan en la app "
        "Apple Wallet de su iPhone. Sin plastico, sin apps que descargar.",
        18, CAFE_OSCURO, False)]])

cards = [
    ("\U0001F4F1", "100% Digital", "El cliente la agrega a Apple Wallet con un toque. Siempre la lleva en su iPhone."),
    ("\u2615", "Sellos automaticos", "Cada compra suma un sello. Al llegar a 10, gana un cafe gratis."),
    ("\U0001F501", "Se actualiza sola", "El saldo de sellos cambia al instante en el telefono del cliente."),
    ("\U0001F4CD", "Notificaciones", "Avisa al cliente cuando pasa cerca de tu cafeteria o gana un premio."),
]
cw = Inches(2.9)
gap = Inches(0.25)
x = Inches(0.6)
for icon, title, desc in cards:
    c = box(s, x, Inches(2.6), cw, Inches(3.6), fill=BLANCO,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    c.line.color.rgb = DORADO
    c.line.width = Pt(1.5)
    box(s, x, Inches(2.6), cw, Inches(0.9), fill=CAFE_MEDIO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    text(s, x, Inches(2.65), cw, Inches(0.8),
         [[(icon, 30, BLANCO, True)]], align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE)
    text(s, x, Inches(3.7), cw, Inches(0.6),
         [[(title, 17, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER)
    text(s, Inches(x.inches + 0.2), Inches(4.35), Inches(cw.inches - 0.4), Inches(1.7),
         [[(desc, 13, GRIS, False)]], align=PP_ALIGN.CENTER)
    x = Emu(x + cw + gap)


# ---- Helper: dibuja un mockup de la tarjeta de Apple Wallet ----
def draw_wallet_card(slide, left, top, sellos=7, total=10, nombre="Juan Perez",
                     nivel="Cafe Lover", width=Inches(3.6)):
    height = Emu(int(width * 1.55))
    # cuerpo de la tarjeta
    card = box(slide, left, top, width, height, fill=CAFE_OSCURO,
               shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    card.line.color.rgb = DORADO
    card.line.width = Pt(1.25)
    L = left.inches
    T = top.inches
    W = width.inches
    # encabezado: logo + sellos
    text(slide, Inches(L + 0.25), Inches(T + 0.18), Inches(W - 1.4), Inches(0.4),
         [[("\u2615 MI CAFETERIA", 13, DORADO, True)]])
    text(slide, Inches(L + W - 1.25), Inches(T + 0.12), Inches(1.05), Inches(0.5),
         [[("SELLOS", 8, DORADO, True)],
          [(f"{sellos}/{total}", 16, BLANCO, True)]], align=PP_ALIGN.RIGHT)
    # barra de progreso (circulos)
    cy = Inches(T + 0.95)
    dot_d = Inches(0.26)
    total_w = W - 0.5
    step = total_w / total
    for i in range(total):
        cx = Inches(L + 0.25 + i * step + (step - 0.26) / 2)
        filled = i < sellos
        d = box(slide, cx, cy, dot_d, dot_d,
                fill=(DORADO if filled else None),
                line=(DORADO if not filled else None),
                shape=MSO_SHAPE.OVAL)
    text(slide, Inches(L + 0.25), Inches(T + 1.35), Inches(W - 0.5), Inches(0.3),
         [[("Tu progreso", 9, DORADO, False)]])
    # secundarios
    text(slide, Inches(L + 0.25), Inches(T + 1.75), Inches(W - 0.5), Inches(0.6),
         [[("CLIENTE", 8, DORADO, True)],
          [(nombre, 13, BLANCO, True)]])
    text(slide, Inches(L + W - 1.7), Inches(T + 1.75), Inches(1.45), Inches(0.6),
         [[("TE FALTAN", 8, DORADO, True)],
          [(f"{total - sellos} cafe(s)", 13, BLANCO, True)]], align=PP_ALIGN.RIGHT)
    # auxiliares
    text(slide, Inches(L + 0.25), Inches(T + 2.45), Inches(W - 0.5), Inches(0.6),
         [[("NIVEL", 8, DORADO, True)],
          [(nivel, 12, BLANCO, True)]])
    # QR
    qr_d = Inches(1.1)
    qr_x = Inches(L + (W - 1.1) / 2)
    qr_y = Inches(T + 3.15)
    box(slide, qr_x, qr_y, qr_d, qr_d, fill=BLANCO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    # patron QR simple
    import random
    random.seed(42)
    cells = 7
    cell = 1.1 / (cells + 1)
    for r in range(cells):
        for c in range(cells):
            if random.random() > 0.5:
                box(slide, Inches(qr_x.inches + cell * (c + 0.5)),
                    Inches(qr_y.inches + cell * (r + 0.5)),
                    Inches(cell), Inches(cell), fill=CAFE_OSCURO)
    text(slide, Inches(L), Inches(T + height.inches - 0.45), Inches(W), Inches(0.35),
         [[("CAFE-AB12CD34", 9, DORADO, False)]], align=PP_ALIGN.CENTER)
    return card


# =====================================================================
# SLIDE 3 - COMO SE VE LA TARJETA
# =====================================================================
s = add_slide()
fill_bg(s, GRIS_CLARO)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Asi se ve la tarjeta en el iPhone", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# mockup central
draw_wallet_card(s, Inches(1.1), Inches(1.6), sellos=7, total=10)

# anotaciones a la derecha
notes = [
    ("Logo y nombre", "Tu marca arriba, siempre visible."),
    ("Contador de sellos", "7 de 10. Se actualiza con cada compra."),
    ("Barra de progreso", "Circulos llenos = sellos ganados."),
    ("Datos del cliente", "Nombre y cuantos cafes le faltan."),
    ("Nivel de cliente", "Lover, Pro, Master, Legend."),
    ("Codigo QR", "El personal lo escanea para sumar sellos."),
]
y = Inches(1.7)
for title, desc in notes:
    box(s, Inches(5.4), y, Inches(0.18), Inches(0.18), fill=DORADO,
        shape=MSO_SHAPE.OVAL)
    text(s, Inches(5.75), Inches(y.inches - 0.1), Inches(7), Inches(0.8),
         [[(title + ":  ", 16, CAFE_OSCURO, True), (desc, 14, GRIS, False)]])
    y = Inches(y.inches + 0.82)

# =====================================================================
# SLIDE 4 - REVERSO DE LA TARJETA
# =====================================================================
s = add_slide()
fill_bg(s, GRIS_CLARO)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("El reverso: informacion y contacto", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# tarjeta reverso
back = box(s, Inches(1.1), Inches(1.6), Inches(3.6), Inches(5.5),
           fill=CREMA, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
back.line.color.rgb = DORADO
back.line.width = Pt(1.25)
secciones = [
    ("Como funciona", "Acumula 1 sello por cada cafe. Al completar 10, tu siguiente cafe es GRATIS."),
    ("Terminos", "Los sellos expiran tras 6 meses de inactividad. No acumulable con otras promociones."),
    ("Contacto", "info@tucafeteria.com\nTel: +52 55 1234 5678\nwww.tucafeteria.com"),
]
y = 1.85
for title, desc in secciones:
    text(s, Inches(1.35), Inches(y), Inches(3.1), Inches(0.35),
         [[(title.upper(), 11, CAFE_MEDIO, True)]])
    text(s, Inches(1.35), Inches(y + 0.35), Inches(3.1), Inches(1.0),
         [[(desc, 11, CAFE_OSCURO, False)]])
    y += 1.55

text(s, Inches(5.4), Inches(2.0), Inches(7.3), Inches(4),
     [[("Todo lo que el cliente necesita saber", 22, CAFE_OSCURO, True)],
      [("", 8, GRIS, False)],
      [("\u2713  Reglas del programa siempre a la mano", 16, GRIS, False)],
      [("\u2713  Telefono, correo y web de tu cafeteria", 16, GRIS, False)],
      [("\u2713  Terminos y condiciones claros", 16, GRIS, False)],
      [("\u2713  Sin letra chica escondida", 16, GRIS, False)],
      [("", 10, GRIS, False)],
      [("El cliente gira la tarjeta tocando el boton \"...\" en Wallet.",
        14, CAFE_MEDIO, False)]])

# =====================================================================
# SLIDE 5 - FLUJO DEL CLIENTE
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Como la usa el cliente", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

pasos = [
    ("1", "\U0001F4E9", "Recibe la tarjeta", "Por email, WhatsApp o escaneando un QR en tu local."),
    ("2", "\u2795", "La agrega a Wallet", "Un toque en \"Agregar a Apple Wallet\". Listo."),
    ("3", "\u2615", "Compra su cafe", "Muestra el QR de la tarjeta al pagar."),
    ("4", "\U0001F389", "Gana cafe gratis", "Al llegar a 10 sellos, el premio aparece solo."),
]
cw = Inches(2.95)
x = Inches(0.55)
for num, icon, title, desc in pasos:
    c = box(s, x, Inches(2.2), cw, Inches(3.8), fill=BLANCO,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    c.line.color.rgb = DORADO
    c.line.width = Pt(1.5)
    circ = box(s, Inches(x.inches + cw.inches/2 - 0.5), Inches(2.5), Inches(1.0), Inches(1.0),
               fill=CAFE_MEDIO, shape=MSO_SHAPE.OVAL)
    text(s, Inches(x.inches + cw.inches/2 - 0.5), Inches(2.55), Inches(1.0), Inches(0.9),
         [[(num, 34, DORADO, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(s, x, Inches(3.7), cw, Inches(0.7),
         [[(icon + "  " + title, 17, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER)
    text(s, Inches(x.inches + 0.2), Inches(4.4), Inches(cw.inches - 0.4), Inches(1.4),
         [[(desc, 13, GRIS, False)]], align=PP_ALIGN.CENTER)
    if num != "4":
        text(s, Inches(x.inches + cw.inches - 0.05), Inches(3.6), Inches(0.6), Inches(0.6),
             [[("\u2192", 28, DORADO, True)]], align=PP_ALIGN.CENTER)
    x = Inches(x.inches + cw.inches + 0.18)

# =====================================================================
# SLIDE 6 - FLUJO DEL PERSONAL (sumar sellos)
# =====================================================================
s = add_slide()
fill_bg(s, GRIS_CLARO)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Como suma sellos tu personal", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# mockup pantalla del personal (telefono/tablet)
phone = box(s, Inches(0.9), Inches(1.6), Inches(3.5), Inches(5.4),
            fill=CAFE_OSCURO, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
phone.line.color.rgb = CAFE_MEDIO
phone.line.width = Pt(2)
box(s, Inches(1.1), Inches(2.0), Inches(3.1), Inches(4.6), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(1.1), Inches(2.15), Inches(3.1), Inches(0.5),
     [[("Panel del personal", 15, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER)
# zona de escaneo QR
scan = box(s, Inches(1.45), Inches(2.75), Inches(2.4), Inches(2.0),
           fill=GRIS_CLARO, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
scan.line.color.rgb = VERDE
scan.line.width = Pt(2)
text(s, Inches(1.45), Inches(3.4), Inches(2.4), Inches(0.8),
     [[("\U0001F4F7", 40, CAFE_MEDIO, True)]], align=PP_ALIGN.CENTER)
text(s, Inches(1.45), Inches(4.25), Inches(2.4), Inches(0.4),
     [[("Escanear QR", 13, GRIS, False)]], align=PP_ALIGN.CENTER)
# boton sumar sello
btn = box(s, Inches(1.45), Inches(5.0), Inches(2.4), Inches(0.7),
          fill=VERDE, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(1.45), Inches(5.05), Inches(2.4), Inches(0.6),
     [[("+1 Sello", 18, BLANCO, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(1.1), Inches(5.85), Inches(3.1), Inches(0.5),
     [[("Juan Perez  \u00b7  8/10 sellos", 12, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER)

# explicacion
steps = [
    ("Escanea el QR del cliente", "Desde un celular, tablet o el lector del POS."),
    ("Presiona \"+1 Sello\"", "El sistema registra la compra al instante."),
    ("El cliente se actualiza solo", "Su iPhone recibe el nuevo saldo por notificacion push."),
    ("Premio automatico", "Al llegar a 10, se genera el cafe gratis sin hacer nada mas."),
]
y = 1.9
for i, (title, desc) in enumerate(steps, 1):
    box(s, Inches(5.2), Inches(y), Inches(0.55), Inches(0.55),
        fill=CAFE_MEDIO, shape=MSO_SHAPE.OVAL)
    text(s, Inches(5.2), Inches(y), Inches(0.55), Inches(0.55),
         [[(str(i), 20, DORADO, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(s, Inches(5.95), Inches(y - 0.05), Inches(6.8), Inches(1.1),
         [[(title, 18, CAFE_OSCURO, True)], [(desc, 14, GRIS, False)]])
    y += 1.25

# =====================================================================
# SLIDE 7 - ARQUITECTURA / COMO FUNCIONA POR DENTRO
# =====================================================================
s = add_slide()
fill_bg(s, CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.4), Inches(12), Inches(0.7),
     [[("Como funciona por dentro", 32, BLANCO, True)]])

def flow_box(slide, left, top, w, h, title, sub, fill, tcolor):
    b = box(slide, left, top, w, h, fill=fill, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    b.line.color.rgb = DORADO
    b.line.width = Pt(1.25)
    text(slide, left, Inches(top.inches + 0.15), w, Inches(0.5),
         [[(title, 16, tcolor, True)]], align=PP_ALIGN.CENTER)
    text(slide, Inches(left.inches + 0.1), Inches(top.inches + 0.7), Inches(w.inches - 0.2), Inches(h.inches - 0.8),
         [[(sub, 11, tcolor, False)]], align=PP_ALIGN.CENTER)
    return b

bw = Inches(2.6)
bh = Inches(1.7)
ty = Inches(2.0)
flow_box(s, Inches(0.5), ty, bw, bh, "\U0001F4B3 Compra", "El cliente paga su cafe en tu local", CREMA, CAFE_OSCURO)
flow_box(s, Inches(3.45), ty, bw, bh, "\U0001F5A5 Servidor", "Suma el sello y guarda en la base de datos", DORADO, CAFE_OSCURO)
flow_box(s, Inches(6.4), ty, bw, bh, "\U0001F514 Push APNs", "Apple avisa al iPhone del cliente", CREMA, CAFE_OSCURO)
flow_box(s, Inches(9.35), ty, bw, bh, "\U0001F4F1 Wallet", "La tarjeta se actualiza sola", DORADO, CAFE_OSCURO)
for fx in [3.2, 6.15, 9.1]:
    text(s, Inches(fx), Inches(2.5), Inches(0.5), Inches(0.6),
         [[("\u2192", 30, DORADO, True)]], align=PP_ALIGN.CENTER)

text(s, Inches(0.5), Inches(4.3), Inches(12.3), Inches(2.6),
     [[("Tecnologia usada", 20, DORADO, True)],
      [("", 8, BLANCO, False)],
      [("\u2022  Node.js + Express  \u2014  el servidor que genera y firma las tarjetas", 15, CREMA, False)],
      [("\u2022  SQLite  \u2014  base de datos de clientes y sus sellos (sin servidor externo)", 15, CREMA, False)],
      [("\u2022  @walletpass/pass-js  \u2014  crea el archivo .pkpass firmado con tus certificados de Apple", 15, CREMA, False)],
      [("\u2022  APNs (Apple Push Notification)  \u2014  actualiza las tarjetas en tiempo real", 15, CREMA, False)],
      [("\u2022  Web Service de Apple Wallet  \u2014  protocolo oficial de registro y actualizacion", 15, CREMA, False)]])

# =====================================================================
# SLIDE 8 - PASOS PARA LANZAR
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Que necesitas para lanzarlo", 32, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

items = [
    ("\U0001F34E", "Cuenta Apple Developer", "99 USD/ano. Necesaria para firmar las tarjetas."),
    ("\U0001F510", "Certificados", "Pass Type ID + certificado de Apple (guia incluida)."),
    ("\U0001F3A8", "Tu marca", "Logo e imagenes de la cafeteria."),
    ("\U0001F310", "Servidor HTTPS", "Para que las tarjetas se actualicen solas."),
    ("\u2699", "Configuracion", "Editar el archivo .env con tus datos."),
    ("\U0001F680", "Listo", "Generar tarjetas y entregarlas a clientes."),
]
cw = Inches(3.9)
ch = Inches(1.55)
x0 = 0.6
positions = [(x0, 1.5), (x0+4.25, 1.5), (x0+8.5, 1.5),
             (x0, 3.3), (x0+4.25, 3.3), (x0+8.5, 3.3)]
for (icon, title, desc), (px, py) in zip(items, positions):
    c = box(s, Inches(px), Inches(py), cw, ch, fill=BLANCO,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    c.line.color.rgb = DORADO
    c.line.width = Pt(1.25)
    text(s, Inches(px + 0.15), Inches(py + 0.15), Inches(1.0), Inches(1.2),
         [[(icon, 32, CAFE_MEDIO, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(s, Inches(px + 1.15), Inches(py + 0.2), Inches(cw.inches - 1.3), Inches(0.5),
         [[(title, 16, CAFE_OSCURO, True)]])
    text(s, Inches(px + 1.15), Inches(py + 0.7), Inches(cw.inches - 1.3), Inches(0.8),
         [[(desc, 12, GRIS, False)]])

text(s, Inches(0.6), Inches(5.4), Inches(12), Inches(1.5),
     [[("\u2705  El codigo de la app ya esta listo y sin errores. Solo faltan tus "
        "credenciales de Apple y las imagenes de marca.", 16, VERDE, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# =====================================================================
# SLIDE 9 - BENEFICIOS / CIERRE
# =====================================================================
s = add_slide()
fill_bg(s, CAFE_OSCURO)
box(s, 0, Inches(5.4), SW, Inches(0.12), fill=DORADO)
text(s, Inches(0.6), Inches(0.7), Inches(12), Inches(1.0),
     [[("\u00bfPor que conviene?", 36, DORADO, True)]])

beneficios = [
    ("\U0001F501", "Clientes que vuelven", "El sello incompleto motiva la siguiente visita."),
    ("\U0001F4B0", "Cero costo de plastico", "Sin imprimir ni reponer tarjetas fisicas."),
    ("\U0001F4CA", "Conoces a tus clientes", "Datos de visitas y consumo para tus promociones."),
    ("\U0001F4F2", "Marketing directo", "Notificaciones cuando pasan cerca de tu local."),
]
y = 1.9
for icon, title, desc in beneficios:
    box(s, Inches(0.8), Inches(y), Inches(0.7), Inches(0.7),
        fill=DORADO, shape=MSO_SHAPE.OVAL)
    text(s, Inches(0.8), Inches(y), Inches(0.7), Inches(0.7),
         [[(icon, 22, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(s, Inches(1.75), Inches(y - 0.05), Inches(10.5), Inches(0.9),
         [[(title + "  \u2014  ", 20, BLANCO, True), (desc, 16, CREMA, False)]],
         anchor=MSO_ANCHOR.MIDDLE)
    y += 0.85

text(s, Inches(0.8), Inches(5.7), Inches(11.7), Inches(1.2),
     [[("\u2615 Tu cafeteria, en el bolsillo de cada cliente.", 24, DORADO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# ---- Guardar ----
out = "Tarjeta_Fidelidad_Apple_Wallet.pptx"
prs.save(out)
print(f"Presentacion generada: {out}")
print(f"Total de diapositivas: {len(prs.slides._sldIdLst)}")
