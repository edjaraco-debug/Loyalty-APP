"""
Genera una presentacion PowerPoint con la GUIA PASO A PASO para poner en linea
y funcionando la app de tarjeta de fidelidad para Apple Wallet, explicada como
si la persona no supiera nada del tema: desde cero hasta la app publicada y
trabajando de verdad.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ---- Paleta de marca (cafeteria) ----
CAFE_OSCURO = RGBColor(0x4A, 0x2F, 0x1C)
CAFE_MEDIO = RGBColor(0x6F, 0x4E, 0x37)
CREMA = RGBColor(0xFF, 0xF4, 0xE6)
DORADO = RGBColor(0xD6, 0xB2, 0x82)
VERDE = RGBColor(0x2E, 0x7D, 0x32)
AZUL = RGBColor(0x2B, 0x57, 0x9A)
ROJO = RGBColor(0xB0, 0x3A, 0x2E)
BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
GRIS = RGBColor(0x66, 0x66, 0x66)
GRIS_CLARO = RGBColor(0xEE, 0xE8, 0xE0)
CODE_BG = RGBColor(0x2B, 0x20, 0x18)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
SW = prs.slide_width
SH = prs.slide_height
BLANK = prs.slide_layouts[6]


def add_slide():
    return prs.slides.add_slide(BLANK)


def fill_bg(slide, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, SH)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    s.line.fill.background()
    s.shadow.inherit = False
    slide.shapes._spTree.remove(s._element)
    slide.shapes._spTree.insert(2, s._element)
    return s


def box(slide, left, top, width, height, fill=None, line=None,
        shape=MSO_SHAPE.RECTANGLE, line_w=Pt(1)):
    s = slide.shapes.add_shape(shape, left, top, width, height)
    if fill is None:
        s.fill.background()
    else:
        s.fill.solid()
        s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = line_w
    s.shadow.inherit = False
    return s


def text(slide, left, top, width, height, runs, align=PP_ALIGN.LEFT,
         anchor=MSO_ANCHOR.TOP, wrap=True, font="Segoe UI", space=None):
    """runs: lista de (texto, tamano, color, bold) o lista de parrafos."""
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = Pt(4)
    tf.margin_right = Pt(4)
    tf.margin_top = Pt(2)
    tf.margin_bottom = Pt(2)
    if isinstance(runs[0], tuple):
        runs = [runs]
    for i, para in enumerate(runs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if space is not None:
            p.space_after = Pt(space)
        for (t, size, color, bold) in para:
            r = p.add_run()
            r.text = t
            r.font.size = Pt(size)
            r.font.color.rgb = color
            r.font.bold = bold
            r.font.name = font
    return tb


def code_box(slide, left, top, width, height, lines, comment_prefix="#"):
    """Caja oscura estilo terminal con texto monoespaciado."""
    b = box(slide, left, top, width, height, fill=CODE_BG,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    b.line.color.rgb = DORADO
    b.line.width = Pt(1)
    paras = []
    for ln in lines:
        col = DORADO if ln.strip().startswith(comment_prefix) else CREMA
        paras.append([(ln if ln else " ", 13, col, False)])
    text(slide, Emu(left + Inches(0.18)), Emu(top + Inches(0.12)),
         Emu(width - Inches(0.36)), Emu(height - Inches(0.24)),
         paras, font="Consolas", space=2)
    return b


def step_header(slide, num, title):
    fill_bg(slide, CREMA)
    box(slide, 0, 0, SW, Inches(1.2), fill=CAFE_OSCURO)
    box(slide, 0, Inches(1.2), SW, Inches(0.07), fill=DORADO)
    circ = box(slide, Inches(0.5), Inches(0.24), Inches(0.72), Inches(0.72),
               fill=DORADO, shape=MSO_SHAPE.OVAL)
    text(slide, Inches(0.5), Inches(0.24), Inches(0.72), Inches(0.72),
         [[(str(num), 26, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE)
    text(slide, Inches(1.45), Inches(0.2), Inches(11.4), Inches(0.8),
         [[("PASO " + str(num), 12, DORADO, True)],
          [(title, 26, BLANCO, True)]],
         anchor=MSO_ANCHOR.MIDDLE)


def bullets(slide, left, top, width, height, items, size=15, gap=8,
            color=CAFE_OSCURO, marker="\u2022 "):
    paras = []
    for it in items:
        if isinstance(it, tuple):
            txt, c, b = it
        else:
            txt, c, b = it, color, False
        paras.append([(marker, size, DORADO, True), (txt, size, c, b)])
    text(slide, left, top, width, height, paras, space=gap)


# =====================================================================
# SLIDE 1 - PORTADA
# =====================================================================
s = add_slide()
fill_bg(s, CAFE_OSCURO)
box(s, 0, Inches(5.6), SW, Inches(0.12), fill=DORADO)
box(s, Inches(0.9), Inches(2.3), Inches(1.7), Inches(1.7), fill=DORADO,
    shape=MSO_SHAPE.OVAL)
text(s, Inches(0.9), Inches(2.45), Inches(1.7), Inches(1.4),
     [[("\U0001F680", 54, CAFE_OSCURO, True)]], align=PP_ALIGN.CENTER,
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(2.95), Inches(1.9), Inches(9.6), Inches(1.6),
     [[("Pon tu app en linea", 42, BLANCO, True)],
      [("paso a paso, desde cero", 42, DORADO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(3.0), Inches(3.7), Inches(9.6), Inches(1.4),
     [[("Guia para llevar la Tarjeta de Fidelidad de Apple Wallet", 20, CREMA, False)],
      [("desde tu computadora hasta estar publicada y funcionando.", 20, CREMA, False)]])
text(s, Inches(0.9), Inches(6.5), Inches(11.5), Inches(0.6),
     [[("Explicado sin tecnicismos  \u00b7  Para alguien que empieza de cero  \u00b7  Junio 2026",
        14, DORADO, False)]])

# =====================================================================
# SLIDE 2 - EL CAMINO COMPLETO (MAPA)
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("El camino completo, de un vistazo", 30, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(0.6), Inches(1.25), Inches(12.1), Inches(0.6),
     [[("Son 11 pasos. No te asustes: vamos uno por uno y te digo exactamente que hacer.",
        16, CAFE_OSCURO, False)]])

pasos = [
    ("1", "Instalar\nherramientas"),
    ("2", "Descargar\nel codigo"),
    ("3", "Certificados\nde Apple"),
    ("4", "Base de datos\n(PostgreSQL)"),
    ("5", "Redis\n(cola push)"),
    ("6", "Configurar\nel .env"),
    ("7", "Elegir\nhosting"),
    ("8", "Subir y\ndesplegar"),
    ("9", "Inicializar\nla base"),
    ("10", "Crear cafeteria\nde prueba"),
    ("11", "Probar en\nel iPhone"),
]
# rejilla 4 x 3
cw, ch = Inches(2.85), Inches(1.45)
gx, gy = Inches(0.18), Inches(0.28)
x0, y0 = Inches(0.7), Inches(2.1)
for i, (n, t) in enumerate(pasos):
    col = i % 4
    row = i // 4
    x = Emu(x0 + col * (cw + gx))
    y = Emu(y0 + row * (ch + gy))
    c = box(s, x, y, cw, ch, fill=BLANCO, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    c.line.color.rgb = DORADO
    c.line.width = Pt(1.25)
    box(s, x, y, Inches(0.7), ch, fill=CAFE_MEDIO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    text(s, x, y, Inches(0.7), ch, [[(n, 24, BLANCO, True)]],
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(s, Emu(x + Inches(0.78)), y, Emu(cw - Inches(0.85)), ch,
         [[(line, 14, CAFE_OSCURO, True)] for line in t.split("\n")],
         anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(0.7), Inches(6.95), Inches(12), Inches(0.4),
     [[("Tip: haz un paso, comprueba que funciona, y sigue con el siguiente.",
        13, GRIS, False)]])

# =====================================================================
# SLIDE 3 - ANTES DE EMPEZAR (CHECKLIST)
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Antes de empezar: que necesitas tener", 30, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

items_izq = [
    ("Una computadora (Windows o Mac) con internet.", VERDE, False),
    ("Un iPhone para probar la tarjeta al final.", VERDE, False),
    ("Un correo electronico que revises.", VERDE, False),
    ("Una tarjeta de credito (para la cuenta de Apple y el hosting).", VERDE, False),
]
items_der = [
    ("Cuenta de Apple Developer: 99 USD/ano. Es obligatoria para Wallet.", CAFE_OSCURO, True),
    ("Paciencia para el primer dia: configurar Apple es lo mas lento.", CAFE_OSCURO, False),
    ("Este proyecto (la carpeta con el codigo) en tu computadora.", CAFE_OSCURO, False),
    ("No necesitas saber programar: solo copiar y pegar comandos.", VERDE, True),
]
box(s, Inches(0.6), Inches(1.5), Inches(6.0), Inches(5.2), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
text(s, Inches(0.85), Inches(1.7), Inches(5.5), Inches(0.5),
     [[("Lo basico", 19, CAFE_OSCURO, True)]])
bullets(s, Inches(0.9), Inches(2.4), Inches(5.4), Inches(4.0), items_izq,
        size=15, gap=14, marker="\u2713  ")
box(s, Inches(6.9), Inches(1.5), Inches(5.85), Inches(5.2), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
text(s, Inches(7.15), Inches(1.7), Inches(5.4), Inches(0.5),
     [[("Cuentas y permisos", 19, CAFE_OSCURO, True)]])
bullets(s, Inches(7.2), Inches(2.4), Inches(5.3), Inches(4.0), items_der,
        size=15, gap=14, marker="\u2713  ")

# =====================================================================
# Helper para slides de "paso" con explicacion + comandos
# =====================================================================
def paso_slide(num, title, intro, code_lines=None, notas=None,
               code_height=2.0, intro_color=CAFE_OSCURO):
    s = add_slide()
    step_header(s, num, title)
    text(s, Inches(0.6), Inches(1.5), Inches(12.1), Inches(1.1),
         [[(intro, 16, intro_color, False)]])
    top = 2.7
    if code_lines:
        code_box(s, Inches(0.6), Inches(top), Inches(12.1),
                 Inches(code_height), code_lines)
        top += code_height + 0.3
    if notas:
        box(s, Inches(0.6), Inches(top), Inches(12.1),
            Inches(6.9 - top), fill=BLANCO,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
        bullets(s, Inches(0.85), Inches(top + 0.18), Inches(11.7),
                Inches(6.6 - top), notas, size=14, gap=8)
    return s


# =====================================================================
# SLIDE 4 - PASO 1: HERRAMIENTAS
# =====================================================================
paso_slide(
    1, "Instalar las herramientas en tu computadora",
    "La app esta hecha con Node.js. Tambien necesitas Git (para el codigo) y un "
    "editor. Descarga e instala estos tres programas (siguiente, siguiente, listo):",
    code_lines=[
        "# 1) Node.js 18 o superior  ->  https://nodejs.org  (boton verde LTS)",
        "# 2) Git                    ->  https://git-scm.com/downloads",
        "# 3) Visual Studio Code     ->  https://code.visualstudio.com",
        "",
        "# Para comprobar que Node quedo instalado, abre una terminal y escribe:",
        "node --version",
        "npm --version",
    ],
    code_height=2.5,
    notas=[
        ("\"Terminal\" en Windows es PowerShell; en Mac es la app Terminal.", CAFE_OSCURO, False),
        ("Si node --version muestra un numero (ej. v20.11.0), vas bien.", VERDE, True),
        ("Reinicia la terminal despues de instalar para que reconozca los comandos.", CAFE_OSCURO, False),
    ],
)

# =====================================================================
# SLIDE 5 - PASO 2: DESCARGAR EL CODIGO
# =====================================================================
paso_slide(
    2, "Descargar el codigo del proyecto",
    "Lleva el proyecto a tu computadora y deja instaladas sus piezas internas "
    "(librerias) con un solo comando.",
    code_lines=[
        "# Abre la terminal en la carpeta donde quieras guardar el proyecto.",
        "# Si ya tienes la carpeta, solo entra en ella y salta al npm install.",
        "",
        "cd \"ruta/donde/guardas/proyectos\"",
        "git clone <URL-de-tu-repositorio> fidelidad",
        "cd fidelidad",
        "",
        "# Instala todo lo que la app necesita por dentro:",
        "npm install",
    ],
    code_height=3.0,
    notas=[
        ("npm install descarga las librerias (Express, BullMQ, pg...). Tarda 1-2 min.", CAFE_OSCURO, False),
        ("Si no usas Git, tambien puedes copiar la carpeta del proyecto a mano.", CAFE_OSCURO, False),
    ],
)

# =====================================================================
# SLIDE 6 - PASO 3: CERTIFICADOS DE APPLE
# =====================================================================
paso_slide(
    3, "Crear los certificados de Apple",
    "Apple exige unos certificados para firmar las tarjetas. Es el paso mas tecnico, "
    "pero solo se hace una vez. Estos son los archivos que debes dejar en la carpeta certs/:",
    code_lines=[
        "certs/signerCert.pem   # tu certificado del Pass Type ID",
        "certs/signerKey.pem    # la clave privada de ese certificado",
        "certs/wwdr.pem         # certificado intermedio de Apple (WWDR)",
    ],
    code_height=1.7,
    notas=[
        ("En developer.apple.com creas un \"Pass Type ID\" (ej. pass.com.tucafe.fidelidad).", CAFE_OSCURO, True),
        ("Generas su certificado, lo exportas y lo conviertes a .pem (pasos en el README).", CAFE_OSCURO, False),
        ("Apunta tu Team ID (10 caracteres) y el Pass Type ID: los usaras en el .env.", CAFE_OSCURO, False),
        ("Consejo: pide ayuda a alguien con Mac para esta parte; alli es mas facil exportar.", GRIS, False),
    ],
)

# =====================================================================
# SLIDE 7 - PASO 4: BASE DE DATOS POSTGRESQL
# =====================================================================
paso_slide(
    4, "Conseguir una base de datos PostgreSQL",
    "Aqui se guardan tus cafeterias, clientes y sellos. Lo mas facil es contratar una "
    "base \"gestionada\" (alguien la mantiene por ti). Opciones gratuitas o baratas:",
    code_lines=[
        "# Proveedores recomendados (crean la base en minutos):",
        "#   - Neon        ->  https://neon.tech",
        "#   - Supabase    ->  https://supabase.com",
        "#   - Render      ->  https://render.com  (PostgreSQL)",
        "",
        "# Te daran una CADENA DE CONEXION parecida a esta:",
        "postgres://usuario:clave@host.proveedor.com:5432/basededatos",
    ],
    code_height=2.6,
    notas=[
        ("Copia esa cadena: sera tu variable DATABASE_URL en el paso 6.", CAFE_OSCURO, True),
        ("Si el proveedor exige conexion segura, mas adelante pondras PGSSL=true.", CAFE_OSCURO, False),
        ("Para solo probar en tu PC, puedes usar Docker; pero para \"en linea\" usa un proveedor.", GRIS, False),
    ],
)

# =====================================================================
# SLIDE 8 - PASO 5: REDIS
# =====================================================================
paso_slide(
    5, "Conseguir Redis (la cola de notificaciones)",
    "Redis es una pieza rapida que guarda en fila los avisos push para que el sistema "
    "no se atasque y reintente solo si Apple falla. Tambien se contrata gestionado:",
    code_lines=[
        "# Proveedores de Redis:",
        "#   - Upstash     ->  https://upstash.com   (plan gratis para empezar)",
        "#   - Render      ->  https://render.com     (Key Value / Redis)",
        "",
        "# Te daran una cadena parecida a:",
        "redis://default:clave@host.proveedor.com:6379",
    ],
    code_height=2.3,
    notas=[
        ("Esa cadena sera tu variable REDIS_URL en el paso 6.", CAFE_OSCURO, True),
        ("Es opcional: si la dejas vacia, los push se envian directos (bien para pruebas,", CAFE_OSCURO, False),
        ("pero para muchos clientes conviene usar Redis para que todo sea rapido y fiable).", CAFE_OSCURO, False),
    ],
)

# =====================================================================
# SLIDE 9 - PASO 6: CONFIGURAR EL .ENV
# =====================================================================
paso_slide(
    6, "Configurar el archivo .env (tus datos secretos)",
    "El .env es una lista de datos que la app lee al arrancar. Copia el ejemplo y rellena "
    "tus valores. Aqui pegas las cadenas de los pasos 4 y 5, y generas tus claves secretas:",
    code_lines=[
        "WEB_SERVICE_URL=https://tucafeteria.com",
        "PASS_TYPE_IDENTIFIER=pass.com.tucafe.fidelidad",
        "TEAM_IDENTIFIER=ABCDE12345",
        "DATABASE_URL=postgres://usuario:clave@host:5432/basededatos",
        "REDIS_URL=redis://default:clave@host:6379",
        "ENCRYPTION_KEY=<64 caracteres: genera con el comando de abajo>",
        "JWT_SECRET=<minimo 32 caracteres al azar>",
    ],
    code_height=2.7,
    notas=[
        ("Crea el archivo copiando la plantilla:  copy .env.example .env", CAFE_OSCURO, True),
        ("Genera claves seguras:  node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\"", CAFE_OSCURO, False),
        ("Nunca compartas el .env ni lo subas a internet: son tus llaves.", ROJO, True),
    ],
)

# =====================================================================
# SLIDE 10 - PASO 7: ELEGIR HOSTING
# =====================================================================
s = add_slide()
step_header(s, 7, "Elegir donde vivira tu app (hosting)")
text(s, Inches(0.6), Inches(1.5), Inches(12.1), Inches(1.0),
     [[("Tu app necesita estar encendida 24/7 en internet, con direccion HTTPS. "
        "Para eso se usa un \"hosting\". Necesitas DOS piezas corriendo:", 16, CAFE_OSCURO, False)]])
# dos tarjetas
tarjetas = [
    ("\U0001F310", "Servidor web", "Atiende a Apple y a tu panel.",
     "Comando de arranque:", "npm run start"),
    ("\u2699\uFE0F", "Worker de push", "Envia las notificaciones desde la cola.",
     "Comando de arranque:", "npm run worker"),
]
x = Inches(0.6)
for icon, titulo, desc, etiqueta, cmd in tarjetas:
    box(s, x, Inches(2.7), Inches(6.0), Inches(2.4), fill=BLANCO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
    text(s, Emu(x + Inches(0.25)), Inches(2.85), Inches(5.5), Inches(0.6),
         [[(icon + "  " + titulo, 20, CAFE_OSCURO, True)]])
    text(s, Emu(x + Inches(0.25)), Inches(3.45), Inches(5.5), Inches(0.6),
         [[(desc, 14, GRIS, False)]])
    code_box(s, Emu(x + Inches(0.25)), Inches(4.1), Inches(5.5), Inches(0.8), [cmd])
    x = Emu(x + Inches(6.15))
box(s, Inches(0.6), Inches(5.35), Inches(12.1), Inches(1.4), fill=GRIS_CLARO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
bullets(s, Inches(0.85), Inches(5.5), Inches(11.7), Inches(1.2), [
    ("Hosting facil recomendado: Render o Railway. Crean web + worker + base + Redis.", CAFE_OSCURO, True),
    ("Te dan una direccion HTTPS gratis (ej. https://tucafe.onrender.com).", CAFE_OSCURO, False),
    ("Pon esa direccion en WEB_SERVICE_URL y NODE_ENV=production.", CAFE_OSCURO, False),
], size=14, gap=7)

# =====================================================================
# SLIDE 11 - PASO 8: SUBIR Y DESPLEGAR
# =====================================================================
paso_slide(
    8, "Subir el codigo y desplegar",
    "Conecta tu proyecto al hosting. La forma mas comoda es subirlo a GitHub y que el "
    "hosting lo tome de ahi: cada vez que cambies algo, se actualiza solo.",
    code_lines=[
        "# 1) Sube tu codigo a GitHub (una sola vez):",
        "git add .",
        "git commit -m \"Mi app de fidelidad\"",
        "git push",
        "",
        "# 2) En Render/Railway: \"New\" -> conecta tu repo de GitHub.",
        "#    - Servicio 1 (Web):    comando  npm run start",
        "#    - Servicio 2 (Worker): comando  npm run worker",
        "#    - Pega TODAS las variables del .env en el panel del hosting.",
    ],
    code_height=3.2,
    notas=[
        ("Las variables del .env se cargan en el panel del hosting, no en un archivo.", CAFE_OSCURO, True),
        ("Cuando termine el despliegue, abre tu URL: debe responder status: ok.", VERDE, True),
    ],
)

# =====================================================================
# SLIDE 12 - PASO 9: INICIALIZAR LA BASE Y CREAR OPERADOR
# =====================================================================
paso_slide(
    9, "Preparar la base y crear tu usuario principal",
    "Con la app ya en linea, hay que crear las tablas (una sola vez) y tu cuenta de "
    "operador de la plataforma (la cuenta jefe que da de alta cafeterias).",
    code_lines=[
        "# Desde la consola del hosting (o en tu PC apuntando a la base en linea):",
        "",
        "npm run init-db      # crea todas las tablas. No borra nada si ya existen.",
        "",
        "npm run create-owner -- tu@correo.com \"UnaContrasenaSegura\"",
    ],
    code_height=2.2,
    notas=[
        ("init-db lo corres una vez al principio (y tras grandes cambios).", CAFE_OSCURO, False),
        ("create-owner crea al \"jefe\": con el inicias sesion para gestionar todo.", CAFE_OSCURO, True),
        ("Guarda ese correo y contrasena en un lugar seguro.", ROJO, True),
    ],
)

# =====================================================================
# SLIDE 13 - PASO 10: CREAR CAFETERIA DE PRUEBA
# =====================================================================
paso_slide(
    10, "Crear tu primera cafeteria y un cliente",
    "Ya puedes usar la app. Inicias sesion para obtener un \"token\", das de alta una "
    "cafeteria y creas un cliente. Esto se hace con peticiones a la API (o tu panel):",
    code_lines=[
        "# 1) Inicia sesion como operador -> te devuelve un token:",
        "POST https://tu-app.com/auth/login   { email, password }",
        "",
        "# 2) Crea una cafeteria (te devuelve su apiKey: guardala):",
        "POST https://tu-app.com/platform/businesses   { name: \"Mi Cafe\" }",
        "",
        "# 3) Crea un cliente / tarjeta usando la apiKey de la cafeteria:",
        "POST https://tu-app.com/admin/passes   { customerName, email }",
    ],
    code_height=3.0,
    notas=[
        ("Puedes probar estas peticiones con apps como Postman o Insomnia (gratis).", CAFE_OSCURO, False),
        ("Atajo para probar rapido en tu PC: npm run demo crea una cafeteria y tarjeta de ejemplo.", VERDE, True),
    ],
)

# =====================================================================
# SLIDE 14 - PASO 11: PROBAR EN EL IPHONE
# =====================================================================
s = add_slide()
step_header(s, 11, "Probar que funciona en el iPhone")
text(s, Inches(0.6), Inches(1.5), Inches(7.0), Inches(1.0),
     [[("El momento de la verdad. Descarga la tarjeta del cliente, abrela en tu "
        "iPhone y comprueba el ciclo completo:", 16, CAFE_OSCURO, False)]])
pasos_test = [
    ("Descarga el archivo .pkpass del cliente (GET .../download).", CAFE_OSCURO, False),
    ("Abrelo en el iPhone y toca \"Agregar\": entra en Apple Wallet.", CAFE_OSCURO, False),
    ("Suma un sello desde el panel (POST .../sellos).", CAFE_OSCURO, False),
    ("En segundos, la tarjeta del iPhone se actualiza sola.", VERDE, True),
    ("Al llegar a 10 sellos, el cliente gana su cafe gratis.", VERDE, True),
]
bullets(s, Inches(0.7), Inches(2.7), Inches(6.6), Inches(3.6), pasos_test,
        size=15, gap=14, marker="\u2713  ")
# mockup tarjeta a la derecha
def draw_wallet_card(slide, left, top, sellos=7, total=10, nombre="Cliente Demo",
                     nivel="Cafe Lover", width=Inches(3.4)):
    height = Emu(int(width * 1.55))
    card = box(slide, left, top, width, height, fill=CAFE_OSCURO,
               shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    card.line.color.rgb = DORADO
    card.line.width = Pt(1.25)
    text(slide, Emu(left + Inches(0.25)), Emu(top + Inches(0.2)),
         Emu(width - Inches(0.5)), Inches(0.4),
         [[("MI CAFE  \u2615", 14, DORADO, True)]])
    text(slide, Emu(left + Inches(0.25)), Emu(top + Inches(0.7)),
         Emu(width - Inches(0.5)), Inches(0.4),
         [[(nombre, 18, BLANCO, True)]])
    text(slide, Emu(left + Inches(0.25)), Emu(top + Inches(1.15)),
         Emu(width - Inches(0.5)), Inches(0.3),
         [[("Nivel: " + nivel, 12, CREMA, False)]])
    # sellos
    dot = Inches(0.42)
    gap = Inches(0.12)
    per_row = 5
    sx = Emu(left + Inches(0.28))
    sy = Emu(top + Inches(1.7))
    for i in range(total):
        r = i // per_row
        c = i % per_row
        x = Emu(sx + c * (dot + gap))
        y = Emu(sy + r * (dot + gap))
        filled = i < sellos
        d = box(slide, x, y, dot, dot,
                fill=DORADO if filled else CAFE_MEDIO, shape=MSO_SHAPE.OVAL)
        if filled:
            text(slide, x, y, dot, dot, [[("\u2615", 13, CAFE_OSCURO, True)]],
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    text(slide, Emu(left + Inches(0.25)), Emu(top + height - Inches(0.7)),
         Emu(width - Inches(0.5)), Inches(0.5),
         [[(str(sellos) + " / " + str(total) + " sellos", 16, DORADO, True)]])

box(s, Inches(8.1), Inches(1.9), Inches(4.6), Inches(4.8), fill=GRIS_CLARO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
draw_wallet_card(s, Inches(8.85), Inches(2.35), sellos=7)
text(s, Inches(8.1), Inches(6.45), Inches(4.6), Inches(0.4),
     [[("Asi se ve en Apple Wallet", 13, GRIS, False)]], align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 15 - MANTENIMIENTO Y BUENAS PRACTICAS
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("Ya esta en linea: como mantenerla sana", 30, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)
cols = [
    ("\U0001F510", "Seguridad", [
        "Guarda .env y ENCRYPTION_KEY a buen recaudo.",
        "Usa siempre HTTPS (NODE_ENV=production).",
        "Rota las claves de vez en cuando.",
    ]),
    ("\U0001F4BE", "Respaldos", [
        "Activa backups de tu base PostgreSQL.",
        "Si pierdes ENCRYPTION_KEY, pierdes los datos cifrados.",
        "Prueba restaurar un backup alguna vez.",
    ]),
    ("\U0001F4C8", "Crecer", [
        "Lanza mas workers si envias muchos push.",
        "Vigila el panel de tu hosting (CPU, memoria).",
        "Sube de plan cuando tengas mas clientes.",
    ]),
]
x = Inches(0.6)
for icon, titulo, items in cols:
    box(s, x, Inches(1.5), Inches(3.95), Inches(5.2), fill=BLANCO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
    box(s, x, Inches(1.5), Inches(3.95), Inches(0.95), fill=CAFE_MEDIO,
        shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    text(s, x, Inches(1.55), Inches(3.95), Inches(0.85),
         [[(icon + "  " + titulo, 19, BLANCO, True)]],
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    bullets(s, Emu(x + Inches(0.25)), Inches(2.7), Inches(3.5), Inches(3.8),
            [(it, CAFE_OSCURO, False) for it in items], size=14, gap=14)
    x = Emu(x + Inches(4.1))

# =====================================================================
# SLIDE 16 - COSTOS: QUE HAY QUE PAGAR
# =====================================================================
s = add_slide()
fill_bg(s, CREMA)
box(s, 0, 0, SW, Inches(1.1), fill=CAFE_OSCURO)
text(s, Inches(0.6), Inches(0.2), Inches(12), Inches(0.7),
     [[("\u00bfQue tengo que pagar?", 30, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)

# --- Columna 1: Obligatorio ---
box(s, Inches(0.6), Inches(1.45), Inches(3.95), Inches(2.55), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = ROJO
box(s, Inches(0.6), Inches(1.45), Inches(3.95), Inches(0.8), fill=ROJO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(0.6), Inches(1.5), Inches(3.95), Inches(0.7),
     [[("Obligatorio", 18, BLANCO, True)]], align=PP_ALIGN.CENTER,
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(0.85), Inches(2.45), Inches(3.5), Inches(1.5),
     [[("Cuenta Apple Developer", 16, CAFE_OSCURO, True)],
      [("99 USD / ano", 22, ROJO, True)],
      [("Sin esto no hay tarjetas en", 12, GRIS, False)],
      [("Apple Wallet. Es lo unico", 12, GRIS, False)],
      [("100% inevitable.", 12, GRIS, False)]], space=2)

# --- Columna 2: Infraestructura ---
box(s, Inches(4.7), Inches(1.45), Inches(3.95), Inches(2.55), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = AZUL
box(s, Inches(4.7), Inches(1.45), Inches(3.95), Inches(0.8), fill=AZUL,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(4.7), Inches(1.5), Inches(3.95), Inches(0.7),
     [[("Infraestructura", 18, BLANCO, True)]], align=PP_ALIGN.CENTER,
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(4.95), Inches(2.4), Inches(3.5), Inches(1.6),
     [[("Gratis para empezar", 15, VERDE, True)],
      [("Hosting (Render/Railway)", 12, CAFE_OSCURO, False)],
      [("Base de datos (PostgreSQL)", 12, CAFE_OSCURO, False)],
      [("Redis (cola de push)", 12, CAFE_OSCURO, False)],
      [("Al crecer: 15-40 USD / mes", 14, AZUL, True)]], space=3)

# --- Columna 3: Gratis ---
box(s, Inches(8.8), Inches(1.45), Inches(3.95), Inches(2.55), fill=BLANCO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = VERDE
box(s, Inches(8.8), Inches(1.45), Inches(3.95), Inches(0.8), fill=VERDE,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(8.8), Inches(1.5), Inches(3.95), Inches(0.7),
     [[("Gratis", 18, BLANCO, True)]], align=PP_ALIGN.CENTER,
     anchor=MSO_ANCHOR.MIDDLE)
text(s, Inches(9.05), Inches(2.4), Inches(3.5), Inches(1.6),
     [[("Node.js, Git, VS Code", 13, CAFE_OSCURO, False)],
      [("El codigo de la app (es tuyo)", 13, CAFE_OSCURO, False)],
      [("GitHub (guardar/desplegar)", 13, CAFE_OSCURO, False)],
      [("Certificados (van con Apple)", 13, CAFE_OSCURO, False)],
      [("Dominio propio: opcional ~12 USD/ano", 12, GRIS, False)]], space=4)

# --- Franja resumen: dos escenarios ---
box(s, Inches(0.6), Inches(4.25), Inches(12.1), Inches(2.45), fill=CAFE_OSCURO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
text(s, Inches(0.9), Inches(4.4), Inches(11.5), Inches(0.5),
     [[("En resumen", 18, DORADO, True)]])
# escenario A
box(s, Inches(0.9), Inches(4.95), Inches(5.6), Inches(1.55), fill=CAFE_MEDIO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(1.15), Inches(5.1), Inches(5.2), Inches(1.3),
     [[("Para probar / pocos clientes", 15, BLANCO, True)],
      [("Solo 99 USD/ano de Apple.", 16, DORADO, True)],
      [("Todo lo demas puede ser gratis.", 13, CREMA, False)]], space=3)
# escenario B
box(s, Inches(6.8), Inches(4.95), Inches(5.6), Inches(1.55), fill=CAFE_MEDIO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE)
text(s, Inches(7.05), Inches(5.1), Inches(5.2), Inches(1.3),
     [[("Funcionando en serio", 15, BLANCO, True)],
      [("99 USD/ano + ~15-40 USD/mes", 16, DORADO, True)],
      [("de infraestructura (+ dominio opcional).", 13, CREMA, False)]], space=3)
text(s, Inches(0.6), Inches(6.95), Inches(12), Inches(0.4),
     [[("Los planes gratis del hosting pueden \"dormir\" la app; para un negocio real conviene el plan basico de pago.",
        12, GRIS, False)]])

# =====================================================================
# SLIDE 17 - CIERRE / CHECKLIST FINAL
# =====================================================================
s = add_slide()
fill_bg(s, CAFE_OSCURO)
box(s, 0, Inches(1.0), SW, Inches(0.08), fill=DORADO)
text(s, Inches(0.6), Inches(0.3), Inches(12), Inches(0.8),
     [[("\u00a1Listo! Tu app esta publicada y funcionando", 30, BLANCO, True)]],
     anchor=MSO_ANCHOR.MIDDLE)
resumen = [
    "Herramientas instaladas y codigo descargado.",
    "Certificados de Apple en su sitio.",
    "Base de datos PostgreSQL y Redis contratados.",
    ".env configurado con tus datos y claves.",
    "App desplegada en el hosting (web + worker) con HTTPS.",
    "Base inicializada y operador creado.",
    "Cafeteria y cliente de prueba creados.",
    "Tarjeta agregada al iPhone y actualizandose sola.",
]
box(s, Inches(0.9), Inches(1.4), Inches(7.6), Inches(5.4), fill=CREMA,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
text(s, Inches(1.2), Inches(1.6), Inches(7.0), Inches(0.5),
     [[("Checklist final", 20, CAFE_OSCURO, True)]])
bullets(s, Inches(1.25), Inches(2.25), Inches(7.1), Inches(4.4),
        [(it, CAFE_OSCURO, False) for it in resumen], size=15, gap=11,
        marker="\u2713  ")
box(s, Inches(8.9), Inches(1.4), Inches(3.8), Inches(5.4), fill=CAFE_MEDIO,
    shape=MSO_SHAPE.ROUNDED_RECTANGLE).line.color.rgb = DORADO
text(s, Inches(9.1), Inches(2.0), Inches(3.4), Inches(4.0),
     [[("\U0001F389", 54, DORADO, True)],
      [("Siguiente paso:", 16, BLANCO, True)],
      [("comparte el enlace de", 14, CREMA, False)],
      [("descarga de la tarjeta", 14, CREMA, False)],
      [("con tus clientes y", 14, CREMA, False)],
      [("empieza a fidelizar.", 14, CREMA, False)]],
     align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

# =====================================================================
# GUARDAR
# =====================================================================
import os
out = os.path.join(os.path.dirname(__file__), "..",
                   "Guia_Despliegue_Apple_Wallet.pptx")
prs.save(out)
print("Presentacion guardada en:", os.path.abspath(out))
